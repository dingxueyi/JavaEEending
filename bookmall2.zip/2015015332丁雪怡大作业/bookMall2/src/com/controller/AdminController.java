package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bean.Admin;
import com.bean.Page;
import com.dao.AdminDao;
import com.service.AdminService;

@Controller
@RequestMapping("admin")
public class AdminController {
	@Autowired
	private AdminService adminService;
	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}
	public AdminService getAdminService() {
		return adminService;
	}

	
	//����Ա��¼
	@RequestMapping("/login")
	public String login(String admin_name,String admin_password,HttpServletRequest request) {
		Admin admin= new Admin();
		admin.setAdmin_name(admin_name);
		admin.setAdmin_password(admin_password);
		if(adminService.login(admin)) {
			request.getSession().setAttribute("admin_name", admin_name);
			return "redirect:/admin/index.jsp";
		}else {
			request.getSession().setAttribute("error1", "�û������������");
			return "redirect:/admin/login.jsp";
		}
	}
	
	//ɾ������Ա
	@RequestMapping("/delete")
	public String delete(@RequestParam("admin_id")int admin_id,HttpServletRequest request) {
		if(adminService.delete(admin_id)) {
			request.getSession().setAttribute("msg_scgly", "ɾ���ɹ���");
			return "redirect:/admin/list.do";
		}else {
			request.getSession().setAttribute("msg_scgly", "ɾ��ʧ��!");
			return "redirect:/admin/list.do";
		}
	}
	
	//���¹���Ա
	@RequestMapping("/update")
	public String update(String oname,String opassword,String nname,String npassword,HttpServletRequest request) {
		Admin oadmin=new Admin();
		oadmin.setAdmin_name(oname);
		oadmin.setAdmin_password(opassword);
		Admin nadmin=new Admin();
		nadmin.setAdmin_name(nname);
		nadmin.setAdmin_password(npassword);
		if(adminService.update(oadmin, nadmin)) {
			request.getSession().setAttribute("msg_gxgly","�޸ĳɹ�");
			return "redirect:/admin/list.do"; 
		}else {
			request.getSession().setAttribute("msg_gxgly","�޸�ʧ��,��˶����û�����");
			return "redirect:/admin/list.do";
		}
	}
	
	//����Ա�б�
		@RequestMapping("/list")
		public String list(HttpServletRequest request) {
			List<Admin> list=new ArrayList<Admin>();
			//��ҳ
			String pageS = request.getParameter("page");
			Integer dpage=1;
			if(pageS!=null) {
				dpage=Integer.parseInt(pageS);
			}
			Page page = new Page();
			page.setPagecount(10);
			page.setTotalcount(adminService.selectCount());
			page.setTotalpage();
			page.setDpage(dpage);
			list= adminService.list(page);
			request.getSession().setAttribute("page1", page);
			request.getSession().setAttribute("admin_list", list);
			return "redirect:/admin/admin_list.jsp"; 
		}
		
	//���ӹ���Ա
		@RequestMapping("/add")
		public String add(Admin admin,HttpServletRequest request) {
			if(adminService.add(admin)) {
				request.getSession().setAttribute("msg_tjgly", "���ӳɹ���");
				return "redirect:/admin/add_admin.jsp"; 
			}else {
				request.getSession().setAttribute("msg_tjgly", "����ʧ��,������û�����");
				return "redirect:/admin/add_admin.jsp"; 
			}
		}

}
