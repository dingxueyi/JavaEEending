package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bean.BookType;
import com.service.BookTypeService;

@Controller
@RequestMapping("/booktype")
public class BookTypeController {
	@Autowired
	private BookTypeService booktypeservice;

	public BookTypeService getBooktypeservice() {
		return booktypeservice;
	}

	public void setBooktypeservice(BookTypeService booktypeservice) {
		this.booktypeservice = booktypeservice;
	}
	
	//����ͼ��ǰ��ȡ���
		@RequestMapping("addjsp")
		public String addjsp(HttpServletRequest request) {
			List<BookType> typelist = new ArrayList<BookType>();
			typelist = booktypeservice.list();
			request.getSession().setAttribute("typelist", typelist);
			return "redirect:/admin/add_book.jsp";
		}
	
	//�������
		@RequestMapping("add")
		public String add(String booktype, HttpServletRequest request) {
			if(booktypeservice.add(booktype)) {
				request.getSession().setAttribute("tjlb", "���ӳɹ�");
				return "redirect:/admin/addtype.jsp";
			}else {
				request.getSession().setAttribute("tjlb", "����ʧ��");
				return "redirect:/admin/addtype.jsp";
			}
		}
}
