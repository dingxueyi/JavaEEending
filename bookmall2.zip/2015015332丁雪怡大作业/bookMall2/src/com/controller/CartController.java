package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bean.*;
import com.dao.CartDao;
import com.service.BookService;
import com.service.CartService;

@Controller
@RequestMapping("/cart")
public class CartController {
	@Autowired
	private CartService cartservice;

	public CartService getCartservice() {
		return cartservice;
	}

	public void setCartservice(CartService cartservice) {
		this.cartservice = cartservice;
	}
	@Autowired
	private BookService bookservice;
	public BookService getBookService() {
		return bookservice;
	}

	public void setBookService(BookService bookservice) {
		this.bookservice = bookservice;
	}
	
	
	//���ӹ��ﳵ
	@RequestMapping("/add")
	public String get(String book_name,String page_name, HttpServletRequest request) {
		//ͨ��book_name�ҵ�book��ȫ����Ϣ
		Book book = new Book();
		book = cartservice.findbook(book_name);
		//��book��user��Ϣ���浽cart����
		Users user = new Users();
		user = (Users) request.getSession().getAttribute("user");
		if(cartservice.add(book,user)) {
			request.getSession().setAttribute("msg_tjgwc", "���ӳɹ�");
			request.getSession().setAttribute("page", page_name);
			return "redirect:/user/addcart_jg.jsp?page="+page_name;
		}else {
			request.getSession().setAttribute("msg_tjgwc", "����ʧ��");
			request.getSession().setAttribute("page", page_name);
			return "redirect:/user/addcart_jg.jsp";
		}
		
	}
	
	//���ﳵ�б�
	@RequestMapping("/get")
	public String get(HttpServletRequest request) {
		Users user = new Users();
		user = (Users) request.getSession().getAttribute("user");
		if(user==null) {
			return "redirect:/user/login.jsp";
		}else {
			//��ò��ظ���ͼ���б�
			List<Cart> list = new ArrayList<Cart>();
			list = (List<Cart>)cartservice.get(user.getUser_id());
			//���ÿ����ĸ���
			List<Integer> list2  = new ArrayList<Integer>();
			list2 =  (List<Integer>)cartservice.count(user.getUser_id());
			request.getSession().setAttribute("cart_list", list);
			request.getSession().setAttribute("count_list", list2);
			return "redirect:/user/checkout.jsp";
		}
	}
	
	
	//ɾ�����ﳵ
	@RequestMapping("/delete")
	public String delete(String book_name,HttpServletRequest request) {
		Users u = new Users();
		u=(Users)request.getSession().getAttribute("user");
		cartservice.delete(book_name,u.getUser_id());
		return "redirect:/cart/get.do";
	}
	
	//����ɾ��
	@RequestMapping("/delete2")
	public String delete2(@RequestParam("book_name") String[] book_name,HttpServletRequest request) {
		Users u = new Users();
		u=(Users)request.getSession().getAttribute("user");
		for(int i =0; i<book_name.length ; i++) {
			cartservice.delete(book_name[i],u.getUser_id());
		}
		return "redirect:/cart/get.do";
	}
	
	//��չ��ﳵ
	@RequestMapping("/empty")
	public String empty(HttpServletRequest request) {
		Users u = new Users();
		u=(Users)request.getSession().getAttribute("user");
		cartservice.empty(u.getUser_id());
		return "redirect:/cart/get.do";
	}
	
	//���ﳵĳ������һ��
	@RequestMapping("/up")
	public String up(String book_name,HttpServletRequest request) {
		//�����ĸ�����Ϣ
		Book book = new Book();
		book = cartservice.findbook(book_name);
		//���user����Ϣ
		Users u = new Users();
		u=(Users)request.getSession().getAttribute("user");
		//��book��user��Ϣ���浽cart����
		cartservice.add(book,u);
		return "redirect:/cart/get.do";
	}
	
	//���ﳵ����һ��
	@RequestMapping("/down")
	public String down(String book_name,HttpServletRequest request) {
		//�����ĸ�����Ϣ
		Book book = new Book();
		book = cartservice.findbook(book_name);
		//���user����Ϣ
		Users u = new Users();
		u=(Users)request.getSession().getAttribute("user");
		//����
		cartservice.down(book,u);
		return "redirect:/cart/get.do";
	}
	
	//ǰ���µ�(�����ﳵ�е���Ϣ����ҳ�棬Ȼ��ɾ��������Ϣ��ҳ������Ϣ�����µ�����)
	@RequestMapping("/setup")
	public String setup(HttpServletRequest request) {
		//���user����Ϣ
		Users u = new Users();
		u=(Users)request.getSession().getAttribute("user");
		//��õ�ַ�б�
		List<Address> al = new ArrayList<Address>();
		al = cartservice.getaddresslist(u.getUser_id());
		//��ò��ظ���ͼ���б�
		List<Cart> bl = new ArrayList<Cart>();
		bl = (List<Cart>)cartservice.get(u.getUser_id());
		//���ÿ����ĸ���
		List<Integer> cl  = new ArrayList<Integer>();
		cl =  (List<Integer>)cartservice.count(u.getUser_id());
		request.getSession().setAttribute("cart_list", bl);
		request.getSession().setAttribute("count_list", cl);
		request.getSession().setAttribute("address_list", al);
		
		return "redirect:/user/affirm.jsp";
	}
	
	
	//�ڹ��ﳵ���в���������ͼ����������ͼ��
	@RequestMapping("/hotbook")
	public String hotbook(HttpServletRequest request) {
		List<Book> list=new ArrayList<Book>();
		//��ҳ
		String pageS = request.getParameter("hpage");
		Integer dpage=1;
		if(pageS!=null) {
			dpage=Integer.parseInt(pageS);
		}
		Page page = new Page();
		page.setPagecount(9);
		page.setTotalcount(bookservice.selectCount());
		page.setTotalpage();
		page.setDpage(dpage);

		list = cartservice.hotbook(page); 
		request.getSession().setAttribute("allortype", "����ͼ��");
		request.getSession().setAttribute("hpage_products", page);
		request.getSession().setAttribute("list", list);
		request.getSession().setAttribute("type_id", 0);
		return "redirect:/user/products.jsp"; 
	}
}
