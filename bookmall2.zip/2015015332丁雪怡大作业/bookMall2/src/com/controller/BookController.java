package com.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.bean.Admin;
import com.bean.Book;
import com.bean.BookType;
import com.bean.Page;
import com.service.BookService;

@Controller
@RequestMapping("/book")
public class BookController {
	@Autowired
	private BookService bookservice;
	public BookService getBookservice() {
		return bookservice;
	}

	public void setBookservice(BookService bookservice) {
		this.bookservice = bookservice;
	}
	

	//����ͼ��
	@RequestMapping("/add")
	public String add(@RequestParam(value="book_img",required=false) MultipartFile book_img,int book_id,String book_name,String book_publisher,int book_price,String book_data,int type_id, HttpServletRequest request)throws Exception {
		//�ϴ�ͼƬ
		String name = book_img.getName();
		String originalFilename = book_img.getOriginalFilename();
		String filename = originalFilename.substring(originalFilename.lastIndexOf("\\")+1);
		if(originalFilename!=null && !originalFilename.equals("")) {
			byte[] bytes;
			try {
				bytes = book_img.getBytes();
				String realPath = request.getServletContext().getRealPath("/image");
				File  file = new File(realPath+"\\"+filename);
				System.out.print(realPath);
				FileOutputStream fos = new FileOutputStream(file);
				fos.write(bytes);
				fos.flush();
				fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		Book book = new Book();
		book.setBook_data(book_data);
		book.setBook_id(book_id);
		book.setBook_img("../image/"+filename);
		book.setBook_name(book_name);
		book.setBook_price(book_price);
		book.setBook_publisher(book_publisher);
		BookType bt=new BookType();
		bt= bookservice.findtype(type_id);
		book.setBooktype(bt);
		if(bookservice.add(book)) {
			request.getSession().setAttribute("msg_tjts", "���ӳɹ���");
			return "redirect:/admin/add_book.jsp"; 
		}else {
			request.getSession().setAttribute("msg_tjts", "����ʧ�ܻ��Ѵ��ڸ�ͼ�飡");
			return "redirect:/admin/add_book.jsp"; 
		}
	}
	//��̨��ȡͼ���б�
	@RequestMapping("/list")
	public String list(HttpServletRequest request) {
		List<Book> list=new ArrayList<Book>();
		//��ҳ
		String pageS = request.getParameter("page");
		Integer dpage=1;
		if(pageS!=null) {
			dpage=Integer.parseInt(pageS);
		}
		Page page = new Page();
		page.setTotalcount(bookservice.selectCount());
		page.setTotalpage();
		page.setDpage(dpage);
		
		list= bookservice.list(page);
		request.getSession().setAttribute("page2", page);
		request.getSession().setAttribute("book_list", list);
		return "redirect:/admin/book_list.jsp"; 
	}
	
	//ǰ̨��ȡͼ���б�
		@RequestMapping("/all")
		public String all(HttpServletRequest request) {
			List<Book> list=new ArrayList<Book>();
			//��ҳ
			String pageS = request.getParameter("page");
			Integer dpage=1;
			if(pageS!=null) {
				dpage=Integer.parseInt(pageS);
			}
			Page page = new Page();
			page.setPagecount(9);
			page.setTotalcount(bookservice.selectCount());
			page.setTotalpage();
			page.setDpage(dpage);

			list= bookservice.list(page);
			request.getSession().setAttribute("allortype", "ȫ��ͼ��");
			request.getSession().setAttribute("page_products", page);
			request.getSession().setAttribute("list", list);
			request.getSession().setAttribute("type_id", 0);
			return "redirect:/user/products.jsp"; 
		}
	
	
	//ɾ��ͼ��
	@RequestMapping("/delete")
	public String delete(@RequestParam("book_id")int book_id,HttpServletRequest request) {
		if(bookservice.findbyid(book_id)) {
			request.getSession().setAttribute("msg_scts", "ɾ��ʧ�ܣ���ͼ������ڶ����У�");
			return "redirect:/book/list.do";
		}else if(bookservice.delete(book_id)) {
			request.getSession().setAttribute("msg_scts", "ɾ���ɹ���");
			return "redirect:/book/list.do";
		}else {
			request.getSession().setAttribute("msg_scts", "ɾ��ʧ��!");
			return "redirect:/book/list.do";
		}
	}
	
	//�ؼ��ֲ���ͼ��
	@RequestMapping("/findbyword")
	public String findbyword(String word,HttpServletRequest request) {
		List<Book> list=new ArrayList<Book>();
		list= bookservice.findbyword(word);
		request.getSession().setAttribute("book_list", list);
		return "redirect:/admin/book_list2.jsp"; 
	}
	
	//��������ͼ��
	@RequestMapping("/findbytype")
	public String findbytype(int type_id,HttpServletRequest request) {
		List<Book> list=new ArrayList<Book>();
		//��ҳ
		String pageS = request.getParameter("page1");
		Integer dpage=1;
		if(pageS!=null) {
			dpage=Integer.parseInt(pageS);
		}
		Page page_ = new Page();
		page_.setPagecount(9);
		page_.setTotalcount(bookservice.selectCountbytypeid(type_id));
		page_.setTotalpage();
		page_.setDpage(dpage);
		BookType tp=new BookType();
		tp = bookservice.findtype(type_id);
		list= bookservice.findbytype(type_id,page_);
		
		request.getSession().setAttribute("allortype", tp.getType_name());
		request.getSession().setAttribute("type_id", tp.getType_id());
		request.getSession().setAttribute("page_products2", page_);
		request.getSession().setAttribute("list", list);
		return "redirect:/user/products.jsp"; 
	}
	
	//ǰ�˸��ݹؼ��ֲ�ѯ
	@RequestMapping("/findbyword2")
	public String findbyword2(String word,HttpServletRequest request) {
		List<Book> list=new ArrayList<Book>();
		list= bookservice.findbyword(word);
		request.getSession().setAttribute("list", list);
		request.getSession().setAttribute("allortype", "�������");
		return "redirect:/user/products.jsp"; 
	}
	
	//��ȡͼ������(ͨ����������)
	@RequestMapping("/getsingle")
	public String getsingle(String book_name,HttpServletRequest request) {
		Book book = new Book();
		book= bookservice.findbyname(book_name);
		request.getSession().setAttribute("book",book );
		return "redirect:/user/single.jsp";
	}

	
	//����ͼ��
	@RequestMapping("/update")
	public String update(int book_id,String book_name,String book_publisher,int book_price,int type_id,String book_data,HttpServletRequest request) {
		Book book= new Book();
		book.setBook_name(book_name);
		book.setBook_price(book_price);
		book.setBook_publisher(book_publisher);
		book.setBook_data(book_data);
		//�������ֲ���booktype
		BookType bt=new BookType(); 
		bt= bookservice.findtype(type_id);
		book.setBooktype(bt);
		//���и���
		if(bookservice.update(book_id, book)) {
			request.getSession().setAttribute("msg_gxts", "���³ɹ���");
			return "redirect:/book/list.do";
		}else {
			request.getSession().setAttribute("msg_gxts", "����ʧ�ܣ�");
			return "redirect:/book/list.do";
		}
	}
	
	//��ѯ����ͼ�飬id�Ӵ�С���򷵻�
	@RequestMapping("/newbook")
	public String newbook(HttpServletRequest request) {
		List<Book> list=new ArrayList<Book>();
		//��ҳ
		String pageS = request.getParameter("npage");
		Integer dpage=1;
		if(pageS!=null) {
			dpage=Integer.parseInt(pageS);
		}
		Page page = new Page();
		page.setPagecount(9);
		page.setTotalcount(bookservice.selectCount());
		page.setTotalpage();
		page.setDpage(dpage);

		list= bookservice.newbook(page);
		request.getSession().setAttribute("allortype", "����ͼ��");
		request.getSession().setAttribute("npage_products", page);
		request.getSession().setAttribute("list", list);
		request.getSession().setAttribute("type_id", 0);
		return "redirect:/user/products.jsp"; 
	}
	
}
