package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bean.Address;
import com.bean.Admin;
import com.bean.Book;
import com.bean.Cart;
import com.bean.Orders;
import com.bean.Page;
import com.bean.Users;
import com.dao.OrderDao;
import com.service.CartService;
import com.service.OrderService;

@Controller
@RequestMapping("/order")
public class OrderController {
	@Autowired
	private OrderService orderservice;

	public OrderService getOrderservice() {
		return orderservice;
	}

	public void setOrderservice(OrderService orderservice) {
		this.orderservice = orderservice;
	}
	
	
	//���Ӷ���
	@RequestMapping("/add")
	public String add(int address_id,HttpServletRequest request) {
		//���user
		Users u = new Users();
		u = (Users)request.getSession().getAttribute("user");
		//���cartlist��countlist�͵�ַid
		List<Cart> cartl = new ArrayList<Cart>();
		cartl = (List<Cart>)request.getSession().getAttribute("cart_list");
		List<Integer> countl = new ArrayList<Integer>();
		countl = (List<Integer>)request.getSession().getAttribute("count_list");
		//ͨ����ַid�õ���ַ
		Address ad= new Address();
		ad = (Address)orderservice.findaddress(address_id);
		orderservice.add(u.getUser_id(),cartl,countl,address_id);
		request.getSession().setAttribute("cart_list", cartl);
		request.getSession().setAttribute("count_list", countl);
		request.getSession().setAttribute("address", ad);
		return "redirect:/user/hadaffirm.jsp";
	}
	
	//ɾ����������̨��
	@RequestMapping("/delete")
	public String delete(@RequestParam("order_id")int order_id,HttpServletRequest request) {
		if(orderservice.delete(order_id)) {
			request.getSession().setAttribute("msg_scdd", "ɾ���ɹ���");
			return "redirect:/order/list.do";
		}else {
			request.getSession().setAttribute("msg_scdd", "ɾ��ʧ��!");
			return "redirect:/order/list.do";
		}
	}
	
	//��ȡ�����б�(��ҳ)
	@RequestMapping("/list")
	public String list(HttpServletRequest request) {
		List<Orders> list=new ArrayList<Orders>();
		//��ҳ
		String pageS = request.getParameter("page");
		Integer dpage=1;
		if(pageS!=null) {
			dpage=Integer.parseInt(pageS);
		}
		Page page = new Page();
		page.setPagecount(10);
		page.setTotalcount(orderservice.selectCount());
		page.setTotalpage();
		page.setDpage(dpage);
		
		list= orderservice.list(page);
		request.getSession().setAttribute("page4", page);
		request.getSession().setAttribute("orderslist", list);
		return "redirect:/admin/order_list.jsp"; 
	}
	
	//���¶���(���Ķ���״̬)
	@RequestMapping("/update")
	public String update(int order_id,String state,HttpServletRequest request) {
		if(orderservice.update(order_id,state)) {
			request.getSession().setAttribute("msg_gxdd", "���³ɹ���");
			return "redirect:/order/list.do";
		}else {
			request.getSession().setAttribute("msg_gxdd", "���³ɹ�!");
			return "redirect:/order/list.do";
		}
	}
	
	//���ݹؼ��ֲ��Ҷ���
		@RequestMapping("/findbyword")
		public String findbyword(String word,HttpServletRequest request) {
			List<Orders> list=new ArrayList<Orders>();
			list= orderservice.findbyword(word);
			request.getSession().setAttribute("orderslist", list);
			return "redirect:/admin/order_list2.jsp"; 
		}
		
	//ɾ������(ǰ̨)
		@RequestMapping("/delete2")
		public String delete2(int order_id,HttpServletRequest request) {
			String user_name = ((Users)request.getSession().getAttribute("user")).getUser_name();
			orderservice.delete(order_id);
			return "redirect:/user/center.do?user_name="+user_name;
		}
		
	//ȡ������
		@RequestMapping("/cancel")
		public String cancel(int order_id,HttpServletRequest request) {
			String user_name = ((Users)request.getSession().getAttribute("user")).getUser_name();
			orderservice.cancel(order_id);
			return "redirect:/user/center.do?user_name="+user_name;
		}
	
}
