package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bean.Address;
import com.bean.Users;
import com.service.AddressService;
import com.service.AdminService;

@Controller
@RequestMapping("address")
public class AddressController {
	@Autowired
	private AddressService addressService;
	public AddressService getAddressService() {
		return addressService;
	}
	public void setAddressService(AddressService addressService) {
		this.addressService = addressService;
	}
	
	//�����û�idɾ����ַ
//	@RequestMapping("/update")
//	public String delete(int user_id,int index,HttpServletRequest request) {
//		//����user_id���user�ĵ�ַ�б�
//		List<Address> al = new ArrayList<Address>();
//		al = addressService.list(user_id);
//		//ɾ��al��indexΪindex�ĵ�ַ��id��Ӧ�ĵ�ַ
//		int address_id = al.get(index).getAddress_id(); 
//		addressService.update(address_id);
//		List<Address> nal = new ArrayList<Address>();
//		nal =  addressService.list(user_id);
//		request.getSession().setAttribute("address_list", nal);
//		return "redirect:/user/user_center.jsp";
//	}
	
	//���ӵ�ַ
	@RequestMapping("/add")
	public String add(String province , String city , String street , HttpServletRequest request) {
		Users user = new Users();
		user = (Users)request.getSession().getAttribute("user");
		System.out.println(user==null);
		Address ad = new Address();
		ad.setCity(city);
		ad.setProvince(province);
		ad.setStreet(street);
		ad.setUsers(user);
		//����
		addressService.add(ad);
		//���»�ȡaddress�б�
		List<Address> nal = new ArrayList<Address>();
		nal =  addressService.list(user.getUser_id());
		request.getSession().setAttribute("address_list", nal);
		return "redirect:/user/user_center.jsp";
	}
	
	
}
