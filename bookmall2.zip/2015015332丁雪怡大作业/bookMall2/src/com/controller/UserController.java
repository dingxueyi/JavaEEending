package com.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.bean.Address;
import com.bean.Admin;
import com.bean.Book;
import com.bean.BookType;
import com.bean.Orders;
import com.bean.Page;
import com.bean.Users;
import com.dao.UserDao;
import com.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserService userservice;

	public UserService getUserservice() {
		return userservice;
	}

	public void setUserservice(UserService userservice) {
		this.userservice = userservice;
	}
	
	//ɾ���û�
	@RequestMapping("/delete")
	public String delete(@RequestParam("user_id")int user_id,HttpServletRequest request) {
		if(userservice.delete(user_id)) {
			request.getSession().setAttribute("msg_scyh", "ɾ���ɹ���");
			return "redirect:/user/list.do";
		}else {
			request.getSession().setAttribute("msg_scyh", "ɾ��ʧ��!");
			return "redirect:/user/list.do";
		}
	}
	
	
	//ע��
	@RequestMapping("/register")
	public String add(@RequestParam(value="user_image",required=false) MultipartFile user_image,String user_name,String user_password,String user_re_password, String user_telephone,HttpServletRequest request)throws Exception {
		//�ж����������Ƿ���ȷ
		if(!user_password.equals(user_re_password)) {
			request.getSession().setAttribute("msg_thzc", "��ȷ�����������Ƿ���ȷ");
			return "redirect:/user/register.jsp";
		}
		//�жϸ��û����Ƿ����
		if(!userservice.findbyname(user_name)) {
			request.getSession().setAttribute("msg_thzc", "���û����Ѵ���");
			return "redirect:/user/register.jsp";
		}
		
		//�ϴ�ͼƬ
		String name = user_image.getName();
		String originalFilename = user_image.getOriginalFilename();
		String filename = originalFilename.substring(originalFilename.lastIndexOf("\\")+1);
		if(originalFilename!=null && !originalFilename.equals("")) {
			byte[] bytes;
			try {
				bytes = user_image.getBytes();
				String realPath = request.getServletContext().getRealPath("/image");
				File  file = new File(realPath+"\\"+filename);
				System.out.print(realPath);
				FileOutputStream fos = new FileOutputStream(file);
				fos.write(bytes);
				fos.flush();
				fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		 Users user =new Users();
		 user.setImage("../image/"+filename);
		 user.setTelephone(user_telephone);
		 user.setUser_name(user_name);
		 user.setUser_password(user_password);
		if(userservice.register(user)) {
			request.getSession().setAttribute("msg_thzc", "ע��ɹ���");
			return "redirect:/user/register.jsp"; 
		}else {
			request.getSession().setAttribute("msg_thzc", "ע��ʧ�ܣ�");
			return "redirect:/user/register.jsp"; 
		}
			
	}
	
	
	
	//�����û�
	@RequestMapping("/update")
	public String update(int user_id,String user_name,String user_password,String user_telephone,HttpServletRequest request) {
		Users u =new Users();
		u.setTelephone(user_telephone);
		u.setUser_id(user_id);
		u.setUser_name(user_name);
		u.setUser_password(user_password);
		if(userservice.update(u)) {
			request.getSession().setAttribute("msg_gxyh", "���³ɹ���");
			return "redirect:/user/list.do";
		}else {
			request.getSession().setAttribute("msg_gxyh", "����ʧ��!");
			return "redirect:/user/list.do";
		}
	}
	
	//��ȡ�û�������Ϣ(�����û�����)
	@RequestMapping("/center")
	public String center(String user_name,HttpServletRequest request) {
		Users user = new Users();
		user = userservice.findname(user_name);
		List <Address> al = new ArrayList<Address>();
		al = userservice.findaddress(user.getUser_id());
		List <Orders> ol = new ArrayList<Orders>();
		ol = userservice.findbyuser_id(user.getUser_id());
		//����ol��ȡ�����б�
		List<List> ll = new ArrayList<List>();
		ll = userservice.findorderdetail(ol);
		request.getSession().setAttribute("user", user);
		request.getSession().setAttribute("address_list", al);
		request.getSession().setAttribute("order_list", ol);
		request.getSession().setAttribute("order_detail_list", ll);
		return "redirect:/user/user_center.jsp";
	}
	
	
	//��ȡ�û��б�
	@RequestMapping("/list")
	public String list(HttpServletRequest request) { 
		//��ҳ
		String pageS = request.getParameter("page");
		Integer dpage=1;
		if(pageS!=null) {
			dpage=Integer.parseInt(pageS);
		}
		Page page = new Page();
		page.setPagecount(5);
		page.setTotalcount(userservice.selectCount());
		page.setTotalpage();
		page.setDpage(dpage);
		request.getSession().setAttribute("page3", page);
		request.getSession().setAttribute("userslist", userservice.list(page));
		return "redirect:/admin/user_list.jsp"; 
	}
	
	//�û���¼
	@RequestMapping("/login")
	public String login(String user_name,String user_password,HttpServletRequest request) {
		Users user= new Users();
		user= userservice.login(user_name,user_password);
		if(user!=null) {
			request.getSession().setAttribute("user", user);
			return "redirect:/user/index.jsp";
		}else {
			request.getSession().setAttribute("errorMsg", "��˶��û��������룡");
			return "redirect:/user/login.jsp";
		}
	}	
	
	//�˳���¼
	@RequestMapping("/logout")
	public String logout(HttpServletRequest request) {
		request.getSession().invalidate();
		return "redirect:/user/index.jsp";
	}
}
