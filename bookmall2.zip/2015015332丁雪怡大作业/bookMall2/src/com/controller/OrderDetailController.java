package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bean.OrderDetail;
import com.bean.Orders;
import com.dao.OrderDetailDao;
import com.service.OrderDetailService;

@Controller
@RequestMapping("/orderdetail")
public class OrderDetailController {
	@Autowired
	private OrderDetailService orderdetailservice;

	public OrderDetailService getOrderdetailservice() {
		return orderdetailservice;
	}

	public void setOrderdetailservice(OrderDetailService orderdetailservice) {
		this.orderdetailservice = orderdetailservice;
	}
	
	
	//��ѯ���������б�
		@RequestMapping("/list")
		public String list(int order_id,HttpServletRequest request) {
			List<OrderDetail> list=new ArrayList<OrderDetail>();
			list= orderdetailservice.list(order_id);
			request.getSession().setAttribute("orderdetaillist", list);
			return "redirect:/admin/order_detail.jsp"; 
		}
}
