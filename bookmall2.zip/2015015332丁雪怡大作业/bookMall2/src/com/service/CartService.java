package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Address;
import com.bean.Book;
import com.bean.Cart;
import com.bean.OrderDetail;
import com.bean.Page;
import com.bean.Users;
import com.dao.CartDao;

@Service
public class CartService {
	@Autowired
	private CartDao cartdao;

	public CartDao getCartdao() {
		return cartdao;
	}

	public void setCartdao(CartDao cartdao) {
		this.cartdao = cartdao;
	}

	//ͨ��bookname�õ�book�������
	public Book findbook(String book_name) {
		return cartdao.findbook(book_name);
	}

	//���ӵ����ﳵ
	public boolean add(Book book, Users user) {
		return cartdao.add(book,user);
		
	}

	//ͨ��userid��ȡ���ﳵ�б�
	public List<Cart> get(int user_id) {
		return cartdao.get(user_id);
	}

	//��ø����б�
	public List<Integer> count(int user_id) {
		return cartdao.count(user_id);
	}

	//���ﳵɾ��ĳ��Ʒȫ��
	public void delete(String book_name, int user_id) {
		cartdao.delete(book_name,user_id);
	}

	//��չ��ﳵ
	public void empty(int user_id) {
		cartdao.empty(user_id);
		
	}

	//����ĳһ����������
	public void down(Book book, Users u) {
		List<Cart> booklist = new ArrayList<Cart>();
		booklist = cartdao.getonebooklist(book,u);
		//���list�е�һ�����cartidȻ��ɾ����
		int cart_id=booklist.get(0).getCart_id();
		cartdao.deletebycartid(cart_id);
	}

	//���user��Ӧ�ĵ�ַ�б�
	public List<Address> getaddresslist(int user_id) {
		return cartdao. getaddresslist( user_id);
	}

	//����ͼ��
	public List<Book> hotbook(Page page) {
		List<Book> list = new ArrayList<Book>();
		List<OrderDetail> clist = new ArrayList<OrderDetail>();
		clist=cartdao.hotbook(page);
		for(int i = 0 ;i <clist.size();i++) {
			list.add(clist.get(i).getBook());
		}
		return list;
	}

	
	
}
