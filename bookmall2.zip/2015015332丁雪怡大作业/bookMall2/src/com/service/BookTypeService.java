package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.BookType;
import com.dao.BookTypeDao;

@Service
public class BookTypeService {
	@Autowired
	private BookTypeDao booktypedao;
	public BookTypeDao getBooktypedao() {
		return booktypedao;
	}
	public void setBooktypedao(BookTypeDao booktypedao) {
		this.booktypedao = booktypedao;
	}
	
	//��ȡ����б�
	public List<BookType> list() {
		// TODO Auto-generated method stub
		return booktypedao.getList();
	}
	
	//�������
	public boolean add(String typename) {
		if(booktypedao.in(typename)) {
			return false;
		}else if(booktypedao.add(typename)){
			return true;
		}
		else {
			return false;
		}
	}
	
}
