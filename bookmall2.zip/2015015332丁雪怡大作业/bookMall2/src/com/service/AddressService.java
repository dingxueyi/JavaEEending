package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Address;
import com.dao.AddressDao;
import com.dao.AdminDao;

@Service
@Transactional
public class AddressService {
	@Autowired
	private AddressDao addressDao;
	public AddressDao getAddressDao() {
		return addressDao;
	}
	public void setAddressDao(AddressDao addressDao) {
		this.addressDao = addressDao;
	}
	//����id��ȡ��ַ�б�
	public List<Address> list(int user_id) {
		return addressDao.list(user_id);
	}
	
	//ɾ��id��Ӧ��address
	public void delete(int address_id) {
		addressDao.delete(address_id);
	}
	
	//���ӵ�ַ
	public void add(Address ad) {
		addressDao.add(ad);
	}
	
	
}
