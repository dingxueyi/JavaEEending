package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Admin;
import com.bean.Page;
import com.dao.AdminDao;

@Service
@Transactional
public class AdminService {
	@Autowired
	private AdminDao adminDao;
	public void setAdminDao(AdminDao adminDao) {
		this.adminDao = adminDao;
	}
	public AdminDao getAdminDao() {
		return adminDao;
	}
	
	//���ӹ���Ա
	public boolean add(Admin admin) {
		return adminDao.add(admin);
	}
	
	//��ҳ��ʾ����Ա
	public List<Admin> list(Page page){
		List<Admin> list = new ArrayList<Admin>();
		list=adminDao.findByPage(page);
		return list;
	}

	//����Ա��¼
	public boolean login(Admin admin) {
		return adminDao.login(admin);
	}
	
	//����Աɾ��
	public boolean delete(int admin_id) {
		return adminDao.delete(admin_id);
	}
	
	//����Ա����
	public boolean update(Admin oadmin,Admin nadmin) {
		return adminDao.update(oadmin, nadmin);
	}
	public int selectCount() {
		return adminDao.selectCount();
	}
}
