package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.OrderDetail;
import com.bean.Orders;
import com.dao.OrderDetailDao;

@Service
public class OrderDetailService {
	@Autowired
	private OrderDetailDao orderdetaildao;

	public OrderDetailDao getOrderdetaildao() {
		return orderdetaildao;
	}

	public void setOrderdetaildao(OrderDetailDao orderdetaildao) {
		this.orderdetaildao = orderdetaildao;
	}

	public List<OrderDetail> list(int order_id) {
		return orderdetaildao.list(order_id);
	}
	
}
