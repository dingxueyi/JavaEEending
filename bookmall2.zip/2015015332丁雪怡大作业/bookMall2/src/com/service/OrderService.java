package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Address;
import com.bean.Cart;
import com.bean.Orders;
import com.bean.Page;
import com.dao.OrderDao;

@Service
public class OrderService {
	@Autowired
	private OrderDao orderdao;

	public OrderDao getOrderdao() {
		return orderdao;
	}

	public void setOrderdao(OrderDao orderdao) {
		this.orderdao = orderdao;
	}
	
	//��ȡ�����б�
	public List<Orders> list(Page page) {
		return orderdao.list(page);
	}

	//ɾ������
	public boolean delete(int order_id) {
		return orderdao.delete(order_id);
	}
	
	//���¶���
	public boolean update(int order_id, String state) {
		return orderdao.update(order_id,state);
	}
	
	//��������
	public Integer selectCount() {
		return orderdao.selectCount();
	}
	
	//�ؼ��ֲ�ѯ����
	public List<Orders> findbyword(String word) {
		return orderdao.findbyword(word);
	}

	//���ӹ��ﳵ������
	public void add(int user_id, List<Cart> cartl, List<Integer> countl, int address_id) {
		orderdao.add( user_id,  cartl,  countl,  address_id);
	}

	//ͨ����ַid�õ���ַ
	public Address findaddress(int address_id) {
		return orderdao.findaddress(address_id);
		
	}

	//ȡ������
	public void cancel(int order_id) {
		orderdao.cancel(order_id);
	}


	
}
