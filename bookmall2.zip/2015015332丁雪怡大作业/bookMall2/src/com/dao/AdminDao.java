package com.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Admin;
import com.bean.Book;
import com.bean.BookType;
import com.bean.Page;
import com.bean.Users;

@Repository  
@Transactional
public class AdminDao {
	@Autowired
	private SessionFactory sessionFactory;
	
	
	//���ӹ���Ա
	@Transactional
	public boolean add(Admin admin){
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ; 
		Query query = session.createQuery("from Admin where admin_name=? and admin_password=?");
		query.setParameter(0, admin.getAdmin_name());
		query.setParameter(1, admin.getAdmin_password());
		Admin a=new Admin();
		a=(Admin) query.uniqueResult();
		if(a==null) {
			session.save(admin);
			tran.commit();
			session.close();
			return true;
		}else {
			return false;
		}
	}
	
	//����ҳ����ʾ����Ա�б�
	@Transactional
	public List<Admin> findByPage(Page page){
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		List<Admin> list= new ArrayList<Admin>();
		Query query = session.createQuery("from Admin");
		query.setFirstResult((page.getDpage()-1)*page.getPagecount());
		query.setMaxResults(page.getPagecount());
		list = query.list(); 
		tran.commit();
		session.close(); 
		return list;
	}
	
	//����Ա��¼
	@Transactional
	public boolean login(Admin admin) {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Admin where admin_name=? and admin_password=?");
		query.setParameter(0, admin.getAdmin_name());
		query.setParameter(1, admin.getAdmin_password());
		Admin a=new Admin();
		a=(Admin) query.uniqueResult();
		if(a!=null) {
			return true;
		}else {
			return false;
		}
		
	}
	
	//ɾ������Ա
	@Transactional
	public boolean delete(int admin_id) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;     
        String hql = "Delete FROM Admin Where admin_id=?" ;     
        Query q = session.createQuery(hql) ;     
        q.setInteger(0, admin_id) ;     
        int i= q.executeUpdate() ;     
        tran.commit() ;
		session.close();
        if(i==0) {
        	return false;
        }
        else{
        	return true;
        }
	}

	//���¹���Ա
	@Transactional
	public boolean update(Admin oadmin,Admin nadmin) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ; 
		if(!oadmin.getAdmin_name().equals(nadmin.getAdmin_name())) {
			Query q= session.createQuery("from Admin where admin_name=?");
			q.setString(0,nadmin.getAdmin_name());
			if(q.uniqueResult()==null) { //�鿴�Ƿ���ĵ������Ϸ�
		        q= session.createQuery("from Admin where admin_name=? and admin_password=?"); //�Ϸ���ǰ���²��Ҿ����ݶ�Ӧ��id
		        q.setString(0,oadmin.getAdmin_name());
		        q.setString(1, oadmin.getAdmin_password());
		        Admin o= (Admin)q.uniqueResult();
			    String hql = "update Admin set admin_name=?, admin_password=? where admin_id=? " ;  //����id�����޸ģ���д��������
			    q = session.createQuery(hql) ;
			    q.setString(0,nadmin.getAdmin_name());
			    q.setString(1, nadmin.getAdmin_password());
			    q.setInteger(2, (Integer)o.getAdmin_id()) ;    
			    System.out.println("oadminidΪ��"+o.getAdmin_id());
			    int i= q.executeUpdate() ;
			    tran.commit() ;
				session.close();
			    if(i==0) {
			        return false;
			    }
			    else{
			        return true;
			        }
			}else {//���Ϸ�ֱ�ӱ���
				return false;
			}
		}else {
			    Query q= session.createQuery("from Admin where admin_name=? and admin_password=?"); //�Ϸ���ǰ���²��Ҿ����ݶ�Ӧ��id
		        q.setString(0,oadmin.getAdmin_name());
		        q.setString(1, oadmin.getAdmin_password());
		        Admin o= (Admin)q.uniqueResult();
			    String hql = "update Admin set admin_name=?, admin_password=? where admin_id=? " ;  //����id�����޸ģ���д��������
			    q = session.createQuery(hql) ;
			    q.setString(0,nadmin.getAdmin_name());
			    q.setString(1, nadmin.getAdmin_password());
			    q.setInteger(2, (Integer)o.getAdmin_id()) ;    
			    System.out.println("oadminidΪ��"+o.getAdmin_id());
			    int i= q.executeUpdate() ;
			    tran.commit() ;
				session.close();
			    if(i==0) {
			        return false;
			    }
			    else{
			        return true;
			        }
		}
	}
	//���admin����
	public  int selectCount() {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Query q= session.createQuery("from Admin");
		List<Admin> list = new ArrayList<Admin>();
		list=q.list();
		tran.commit();
		session.close();
		return list.size();
	}

}