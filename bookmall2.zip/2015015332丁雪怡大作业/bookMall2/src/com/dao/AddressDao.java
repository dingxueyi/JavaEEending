package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Address;

@Repository  
@Transactional
public class AddressDao {
	@Autowired
	private SessionFactory sessionFactory;

	//����id��õ�ַ�б�
	public List<Address> list(int user_id) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Query q= session.createQuery("from Address where user_id=?");
		q.setParameter(0, user_id);
		List <Address> al = new ArrayList<Address>();
		al = q.list();
		tran.commit();
		session.close();
		return al;
	}

	//ɾ����ַid��Ӧ�ĵ�ַ
	public void delete(int address_id) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Address ad = new Address();
		ad = session.get(Address.class, address_id);
		session.delete(ad);
		tran.commit();
		session.close();
	}
	
	//���ӵ�ַ
	public void add(Address ad) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		session.save(ad);
		tran.commit();
		session.close();
	}
	
	
}
