 package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.catalina.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Address;
import com.bean.Admin;
import com.bean.Book;
import com.bean.BookType;
import com.bean.OrderDetail;
import com.bean.Orders;
import com.bean.Page;
import com.bean.Users;
@Repository  
public class UserDao {
	@Autowired
	private SessionFactory sessionFactory;
	
	//��ȡ�û��б�
	@Transactional
	public List<Users> findByPage(Page page) {
			Session session = sessionFactory.openSession();
			List<Users> list= new ArrayList<Users>();
			Query query = session.createQuery("from Users");
			query.setFirstResult((page.getDpage()-1)*page.getPagecount());
			query.setMaxResults(page.getPagecount());
			list = query.list(); 
			session.close(); 
			return list;
	}

	//ɾ���û�
	@Transactional
	public boolean delete(int user_id) {
			Session session = sessionFactory.openSession();
			Transaction tran = session.beginTransaction() ;  
			Users user= new Users();
			user=session.get(Users.class, user_id);
			session.delete(user);
	        tran.commit() ;
			session.close();
	        return true;
	}
	//�����û�
	@Transactional
	public boolean update(Users u) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ; 
		Users user =new Users();
		user=session.get(Users.class, u.getUser_id());
		user.setTelephone(u.getTelephone());
		user.setUser_name(u.getUser_name());
		user.setUser_password(u.getUser_password());
		session.update(user);
		tran.commit() ;
		session.close();
		return true;
	}
	
	//��ȡ�û�����
	public int selectCount() {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Query q= session.createQuery("from Users");
		List<Users> list = new ArrayList<Users>();
		list=q.list();
		tran.commit();
		session.close();
		return list.size();
	}
	
	//ͨ���û�������(�������)
	public boolean findbyname(String user_name) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Query q= session.createQuery("from Users where user_name=?");
		q.setParameter(0, user_name);
		List<Users> list = new ArrayList<Users>();
		list=q.list();
		tran.commit();
		session.close();
		if(list==null) {
			return false;
		}else {
			return true;
		}
	}

	//�û�ע��
	public boolean register(Users user) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		session.save(user);
		tran.commit();
		session.close();
		return true;
	}

	//�û���¼
	public Users login(String user_name, String user_password) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Users user = new Users();
		Query q = session.createQuery("from Users where user_name=? and user_password=?");
		q.setParameter(0, user_name);
		q.setParameter(1, user_password);
		user=(Users)q.uniqueResult();
		tran.commit();
		session.close();
		if(user!=null) {
			return user;
		}else {
			return null;
		}
	}
	
	//ͨ���û�������(����user)
		public Users findname(String user_name) {
			Session session = sessionFactory.openSession();
			Transaction tran = session.beginTransaction() ;
			Query q= session.createQuery("from Users where user_name=?");
			q.setParameter(0, user_name);
			Users user = new Users();
			user = (Users)q.uniqueResult();
			tran.commit();
			session.close();
			return user;
			
		}
	
	//�����û�����address�б�
		public List<Address> findaddress(int user_id) {
			Session session = sessionFactory.openSession();
			Transaction tran = session.beginTransaction() ;
			Query q= session.createQuery("from Address where user_id=?");
			q.setParameter(0, user_id);
			List <Address> al = new ArrayList<Address>();
			al = q.list();
			tran.commit();
			session.close();
			return al;
		}

	//�����û�id����order�б�
		public List<Orders> findbyuser_id(int user_id) {
			Session session = sessionFactory.openSession();
			Transaction tran = session.beginTransaction() ;
			Query q= session.createQuery("from Orders where user_id=?");
			q.setParameter(0, user_id);
			List <Orders> ol = new ArrayList<Orders>();
			ol = q.list();
			tran.commit();
			session.close();
			return ol;
		}
		
	//����ol��ȡ�����б�
		public List<List> findorderdetail(List<Orders> ol) {
			Session session = sessionFactory.openSession();
			Transaction tran = session.beginTransaction() ;
			List<List> ll = new ArrayList<List>();
			for(int i=0;i<ol.size();i++) {
				Query q= session.createQuery("from OrderDetail where orders.order_id=?");
				q.setParameter(0, ol.get(i).getOrder_id());
				List<OrderDetail> odl= new ArrayList<OrderDetail>();
				odl = q.list();
				ll.add(odl);
			}
			tran.commit();
			session.close();
			return ll;
		}
	
		
	
}
