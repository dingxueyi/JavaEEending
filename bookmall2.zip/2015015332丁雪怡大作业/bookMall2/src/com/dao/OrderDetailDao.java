package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bean.Admin;
import com.bean.Book;
import com.bean.OrderDetail;
import com.bean.Orders;
@Repository  
public class OrderDetailDao {
	@Autowired
	private SessionFactory sessionFactory;

	public List<OrderDetail> list(int order_id) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ; 
		List<OrderDetail> list= new ArrayList<OrderDetail>();
		Query query = session.createQuery("from OrderDetail where Order_id=?");
		query.setParameter(0, order_id);
		list = query.list(); 
		tran.commit();
		session.close();
		return list;	
	}

	
}
