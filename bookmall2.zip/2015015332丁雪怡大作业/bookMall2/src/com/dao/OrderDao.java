package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.criteria.Order;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bean.Address;
import com.bean.Admin;
import com.bean.Book;
import com.bean.BookType;
import com.bean.Cart;
import com.bean.OrderDetail;
import com.bean.Orders;
import com.bean.Page;
import com.bean.Users;
@Repository  
public class OrderDao {
	@Autowired
	private SessionFactory sessionFactory;
	
	//��ȡ�����б�
	public List<Orders> list(Page page) {
		Session session = sessionFactory.openSession();
		List<Orders> list= new ArrayList<Orders>();
		Query query = session.createQuery("from Orders");
		query.setFirstResult((page.getDpage()-1)*page.getPagecount());
		query.setMaxResults(page.getPagecount());
		list = query.list(); 
		session.close(); 
		return list;
	}
	
	//ɾ������
	public boolean delete(int order_id) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ; 
		session.delete(session.get(Orders.class, order_id));
		tran.commit();
		session.close();
		return true;	
	}

	//���¶���
	public boolean update(int order_id, String state) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ; 
		Orders order = new Orders();
		order = session.get(Orders.class, order_id);
		order.setState(state);
		session.update(order);
		tran.commit();
		session.close();
		return true;
	}

	//��ѯ��������Ŀ
	public Integer selectCount() {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Query q= session.createQuery("from Orders");
		List<Orders> list = new ArrayList<Orders>();
		list=q.list();
		tran.commit();
		session.close();
		return list.size();
	}
	
	//�ؼ��ֲ�ѯ
	public List<Orders> findbyword(String word) {
		Session session = sessionFactory.openSession();
		List<Orders> list= new ArrayList<Orders>();
		Query query = session.createQuery("from Orders where state like ? or users.user_name like ? ");
		query.setParameter(0, "%"+word+"%");
		query.setParameter(1, "%"+word+"%");
		list = query.list();  
		session.close();
		return list;
	}

	//���ӹ��ﳵ������
	public void add(int user_id, List<Cart> cartl, List<Integer> countl, int address_id) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		//���ɾ�����ﳵ
		Query q = session.createQuery("from Cart where users.user_id=?");
		q.setParameter(0,user_id);
		List<Cart> cartlist= new ArrayList<Cart>();
		cartlist = q.list();
		for(int o=0;o<cartlist.size();o++) {
			session.delete(cartlist.get(o));
		}
		//����address_id���ҵ�address
		Query query = session.createQuery("from Address where address_id=?");
		query.setParameter(0, address_id);
		Address ad = new Address();
		ad = (Address)query.uniqueResult();
		//����user_id�ҵ�user
		Query p = session.createQuery("from Users where user_id=?");
		p.setParameter(0, user_id);
		Users u = new Users();
		u = (Users)p.uniqueResult();
		//�õ���ǰʱ���ַ���
		Calendar now = Calendar.getInstance(); 
		String str  = Integer.toString(now.get(Calendar.YEAR))+"-"+Integer.toString(now.get(Calendar.MONTH) + 1)+"-"+Integer.toString(now.get(Calendar.DAY_OF_MONTH));
		//�浽����
		Orders ors = new Orders();
		ors.setAddress(ad);
		ors.setState("δȷ��");
		ors.setUsers(u);
		ors.setOrder_time(str);
		session.save(ors);
		//����
		for(int n=0 ; n<cartl.size();n++) {
			//�浽��������
			OrderDetail od = new OrderDetail();
			od.setBook(cartl.get(n).getBook());
			Number number =countl.get(n);
			int num = number.intValue();
			od.setCount(num);
			od.setOrders(ors);
			session.save(od);
		}
		tran.commit();
		session.close();
	}

	//ͨ����ַid�õ���ַ
	public Address findaddress(int address_id) {
		Session session = sessionFactory.openSession();
		List<Orders> list= new ArrayList<Orders>();
		Query query = session.createQuery("from Address where address_id=?");
		query.setParameter(0,address_id);
		Address ad = new Address();
		ad = (Address)query.uniqueResult();
		session.close();
		return ad;
	}
	
	//�¶����ɹ���ո��û����ﳵ
	public void deletecart(int user_id) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		
		tran.commit();
		session.close();
		
	}
	
	//ȡ������
	public void cancel(int order_id) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Orders o = new Orders();
		o = session.get(Orders.class, order_id);
		o.setState("��ȡ��");
		session.save(o);
		tran.commit();
		session.close();
	}

	
	
}
