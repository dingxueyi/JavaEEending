package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Address;
import com.bean.Book;
import com.bean.BookType;
import com.bean.Cart;
import com.bean.OrderDetail;
import com.bean.Page;
import com.bean.Users;
@Repository  
@Transactional
public class CartDao {
	@Autowired
	private SessionFactory sessionFactory;
	
	//ͨ��book_name�õ�book
	public Book findbook(String book_name) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Query q= session.createQuery("from Book where book_name=?");
		q.setParameter(0, book_name);
		Book book = new Book();
		book = (Book)q.uniqueResult();
		tran.commit();
		session.close();
		return book;
	}

	//���ӵ����ﳵ
	public boolean add(Book book, Users user) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Cart cart = new Cart();
		cart.setBook(book);
		cart.setBook_img(book.getBook_img());
		cart.setBook_name(book.getBook_name());
		cart.setBook_price(book.getBook_price());
		cart.setUsers(user);
		session.save(cart);
		tran.commit();
		session.close();
		return true;
		}

	//ͨ��user_id��ȡ���ﳵ�б�
	public List<Cart> get(int user_id) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Query q= session.createQuery("from Cart where users.user_id = ? group by book.book_name");
		q.setParameter(0, user_id);
		List<Cart> list = new ArrayList<Cart>();
		list = q.list();
		tran.commit();
		session.close();
		return list;
	}
	
	//��ø����б�
	public List<Integer> count(int user_id) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Query q= session.createQuery("select count(book.book_name) from Cart where users.user_id = ? group by book.book_name");
		q.setParameter(0, user_id);
		List <Integer> list= new ArrayList<Integer>();
		list=q.list();
		tran.commit();
		session.close();
		return list;
	}
	
	//���ﳵɾ��ĳ��Ʒȫ��
	public void delete(String book_name, int user_id) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Query q= session.createQuery("delete from Cart where book_name=? and users.user_id = ?");
		q.setParameter(0, book_name);
		q.setParameter(1, user_id);
		int i = q.executeUpdate();
		tran.commit();
		session.close();
	}

	//��չ��ﳵ
	public void empty(int user_id) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Query q= session.createQuery("delete from Cart where users.user_id = ?");
		q.setParameter(0, user_id);
		int i = q.executeUpdate();
		tran.commit();
		session.close();
	}

	//ͨ��book��user���ĳ���û�ĳ������б�
	public List<Cart> getonebooklist(Book book, Users u) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Query q= session.createQuery("from Cart where users.user_id = ? and book_name=?");
		q.setParameter(0, u.getUser_id());
		q.setParameter(1, book.getBook_name());
		List<Cart> list = new ArrayList<Cart>();
		list = q.list();
		tran.commit();
		session.close();
		return list;
	}

	//���ﳵĳ�����һ��
	public void deletebycartid(int cart_id) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Query q= session.createQuery("delete from Cart where cart_id = ?");
		q.setParameter(0, cart_id);
		int i = q.executeUpdate();
		tran.commit();
		session.close();
		
	}

	//ͨ��user_id��õ�ַ�б�
	public List<Address> getaddresslist(int user_id) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ;
		Query q= session.createQuery("from Address where users.user_id = ?");
		q.setParameter(0, user_id);
		List<Address> list = new ArrayList<Address>();
		list = q.list();
		tran.commit();
		session.close();
		return list;
	}

	//����ͼ��
	public List<OrderDetail> hotbook(Page page) {
		Session session = sessionFactory.openSession();
		List<OrderDetail> list= new ArrayList<OrderDetail>();
		Query query = session.createQuery("from OrderDetail as o group by book.book_id order by count(book.book_id) desc");
		query.setFirstResult((page.getDpage()-1)*page.getPagecount());
		query.setMaxResults(page.getPagecount());
		list = query.list();  
		session.close();
		return list;
	}
}
