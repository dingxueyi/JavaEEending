package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bean.Book;
import com.bean.BookType;
@Repository  
public class BookTypeDao {
	@Autowired
	private SessionFactory sessionFactory;
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	//��ȡ�б�
	public List<BookType> getList(){
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ; 
		List<BookType> list= new ArrayList<BookType>();
		Query query = session.createQuery("from BookType");
		list=query.list();
		tran.commit();
		session.close();
		return list;
	}
	
	//�������
	public boolean add(String typename) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ; 
		BookType bt = new BookType();
		bt.setType_name(typename);
		session.save(bt);
		tran.commit();
		session.close();
		return true;
	}
	
	//�ж��Ƿ���ڸ����
	public boolean in(String typename) {
		Session session = sessionFactory.openSession();
		Transaction tran = session.beginTransaction() ; 
		List<BookType> list= new ArrayList<BookType>();
		Query query = session.createQuery("from BookType where type_name= ?");
		query.setParameter(0, typename);
		BookType bt= new BookType();
		bt = (BookType)query.uniqueResult();
		tran.commit();
		session.close();
		if(bt==null) {
			return false;
		}else {
			return true;
		}
	}
}
