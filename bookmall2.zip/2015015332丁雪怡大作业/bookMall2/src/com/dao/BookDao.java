package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Admin;
import com.bean.Book;
import com.bean.BookType;
import com.bean.OrderDetail;
import com.bean.Page;
import com.bean.Users;
@Repository  
public class BookDao {
	@Autowired
	private SessionFactory sessionFactory;
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	//��ȡͼ���б�
	@Transactional
	public List<Book> list(Page page) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		List<Book> list= new ArrayList<Book>();
		Query query = session.createQuery("from Book");
		query.setFirstResult((page.getDpage()-1)*page.getPagecount());
		query.setMaxResults(page.getPagecount());
		list = query.list();  
		session.close();
		return list;
	}
	
	//����ͼ��
	@Transactional
		public boolean add(Book book){
			Session session = sessionFactory.openSession();
			Transaction tran = session.beginTransaction() ; 
			//�鿴�Ƿ����ӵ����ظ�
			Query query = session.createQuery("from Book where book_name=?");
			query.setParameter(0, book.getBook_name());
			Book a=new Book();
			a=(Book) query.uniqueResult();
			if(a==null) {
				session.save(book);
				tran.commit();
				session.close();
				return true;
			}else {
				return false;
			}
	}
	//ɾ��ͼ��
	@Transactional
		public boolean delete(int book_id) {
			Session session = sessionFactory.openSession();
			Transaction tran = session.beginTransaction() ;     
	        session.delete(session.get(Book.class,book_id ));
	        tran.commit() ;
	        session.close();
	        	return true;
		}
	//����ͼ����Ϣ
		@Transactional
		public boolean update(int oid, Book nbook) {
			Session session = sessionFactory.openSession();
			Transaction tran = session.beginTransaction() ; 
			Query q=session.createQuery("update Book set book_name=?,book_publisher=?,book_price=?,booktype.type_id=?,book_data=? where book_id=?"); 
			q.setParameter(0, nbook.getBook_name());
			q.setParameter(1, nbook.getBook_publisher());
			q.setParameter(2, nbook.getBook_price());
			q.setParameter(3, nbook.getBooktype().getType_id());
			q.setParameter(4, nbook.getBook_data());
			q.setParameter(5, oid);
			int i= q.executeUpdate() ;
			tran.commit() ;
			session.close();
			if(i==0) {
				return false;
			}else {
				return true;
			}
		}
		
	//ͨ��typeid����type
		@Transactional
		public BookType fingtype(int type_id) {
			BookType bt= new BookType();
			Session session = sessionFactory.openSession();
			Transaction tran = session.beginTransaction() ; 
			Query q=session.createQuery("from BookType where type_id=?");
			q.setInteger(0, type_id);
			bt=(BookType)q.uniqueResult();
			session.close();
			return bt;
		}
		
	//��ѯ�����Ŀ
		@Transactional
		public int selectCount() {
			Session session = sessionFactory.openSession();
			Transaction tran = session.beginTransaction() ;
			Query q= session.createQuery("from Book");
			List<Book> list = new ArrayList<Book>();
			list=q.list();
			tran.commit();
			session.close();
			return list.size();
		}
		
	//�ؼ��ֲ�ѯ��
		@Transactional
		public List<Book> findbyword(String word) {
			Session session = sessionFactory.openSession();
			List<Book> list= new ArrayList<Book>();
			Query query = session.createQuery("from Book where book_name like ? or book_data like ? or book_publisher like ? or booktype.type_name like ?");
			query.setParameter(0, "%"+word+"%");
			query.setParameter(1, "%"+word+"%");
			query.setParameter(2, "%"+word+"%");
			query.setParameter(3, "%"+word+"%");
			list = query.list();  
			session.close();
			return list;
		}
		
	//�������ͻ�ȡͼ���б�
		public List<Book> findbytype(int type_id, Page page) {
			Session session = sessionFactory.openSession();
			List<Book> list= new ArrayList<Book>();
			Query query = session.createQuery("from Book where booktype.type_id=?");
			query.setParameter(0, type_id);
			query.setFirstResult((page.getDpage()-1)*page.getPagecount());
			query.setMaxResults(page.getPagecount());
			list = query.list();  
			session.close();
			return list;
		}
		
	//�������ͻ�ȡͼ�����
		public Integer selectCountbytypeid(int type_id) {
			Session session = sessionFactory.openSession();
			List<Book> list= new ArrayList<Book>();
			Query query = session.createQuery("from Book where booktype.type_id=?");
			query.setParameter(0, type_id);
			list = query.list();  
			session.close();
			return list.size();
		}
		
	//ͨ��ͼ��������
		public Book findbyname(String book_name) {
			Session session = sessionFactory.openSession();
			Book book= new Book();
			Query query = session.createQuery("from Book where book_name=?");
			query.setParameter(0, book_name);
			book=(Book)query.uniqueResult();
			return book;
		}
	
	//����ͼ��
		public List<Book> newbook(Page page) {
			Session session = sessionFactory.openSession();
			List<Book> list= new ArrayList<Book>();
			Query query = session.createQuery("from Book order by book_id desc");
			query.setFirstResult((page.getDpage()-1)*page.getPagecount());
			query.setMaxResults(page.getPagecount());
			list = query.list();  
			session.close();
			return list;
		}
	
	//ͨ��ͼ��id����
		public boolean findbyid(int book_id) {
			Session session = sessionFactory.openSession();
			Book book= new Book();
			Query query = session.createQuery("from OrderDetail where book.book_id=?");
			query.setParameter(0, book_id);
			List<OrderDetail> odl = new ArrayList<OrderDetail>();
			odl = query.list();
			if(odl.isEmpty()) {
				return false;
			}else {
				return true;
			}
		}
}
