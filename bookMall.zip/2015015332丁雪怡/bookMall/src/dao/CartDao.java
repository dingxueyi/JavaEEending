package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Book;
import bean.BookType;
import bean.Cart;
import db.DBConnection;

public class CartDao {
	public boolean insertNoUser(Book book) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("insert into `cart`(book_img,book_name,book_price) value(?,?,?)");
			 ps.setString(1,book.getBook_img());
			 ps.setString(2,book.getBook_name());
			 ps.setInt(3,book.getBook_price());
			 System.out.print(ps.executeUpdate());
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	public boolean insertYesUser(Book book,String user_name) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("insert into `cart`(book_img,book_name,book_price,user_name) value(?,?,?,?)");
			 ps.setString(1,book.getBook_img());
			 ps.setString(2,book.getBook_name());
			 ps.setInt(3,book.getBook_price());
			 ps.setString(4,user_name);
			 System.out.print(ps.executeUpdate());
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	public List<Cart> CartList() {
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		String word=null;
		List<Cart> list=new ArrayList<Cart>();
		try {
			 ps = connection.prepareStatement("select book_img,book_name,book_price,count(book_name) as count from `cart` where user_name is ? group by book_name");
			 ps.setString(1,word);
			 rs = ps.executeQuery();
			 while(rs.next()){
					Cart cart=new Cart();
					cart.setBook_img(rs.getString("book_img"));
					cart.setBook_name(rs.getString("book_name"));
					cart.setBook_price(rs.getInt("book_price"));
					cart.setCount(rs.getInt("count"));
					list.add(cart);
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	public List<Cart> CartListUser(String user_name) {
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		List<Cart> list=new ArrayList<Cart>();
		try {
			 ps = connection.prepareStatement("select book_img,book_name,book_price,count(book_name) as count from `cart` where user_name=? group by book_name");
			 ps.setString(1,user_name);
			 rs = ps.executeQuery();
			 while(rs.next()){
					Cart cart=new Cart();
					cart.setBook_img(rs.getString("book_img"));
					cart.setBook_name(rs.getString("book_name"));
					cart.setBook_price(rs.getInt("book_price"));
					cart.setCount(rs.getInt("count"));
					list.add(cart);
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	public boolean delete(String book_name) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("delete from `cart` where book_name=?");
			 ps.setString(1,book_name);
			 ps.execute();
			 System.out.print(ps.executeUpdate());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	public boolean deleteWithUser(String book_name,String user_name) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("delete from `cart` where book_name=? and user_name=?");
			 ps.setString(1,book_name);
			 ps.setString(2,user_name);
			 ps.execute();
			 System.out.print(ps.executeUpdate());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	public boolean deletewithuser(String user_name) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("delete from `cart` where user_name=?");
			 ps.setString(1,user_name);
			 ps.execute();
			 System.out.print(ps.executeUpdate());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	
}
