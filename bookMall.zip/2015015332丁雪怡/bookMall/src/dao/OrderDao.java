package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import bean.Admin;
import bean.Book;
import bean.BookType;
import bean.Orders;
import bean.Page;
import db.DBConnection;

public class OrderDao {
	public List<Orders> getList(){
		List<Orders> list = new ArrayList<Orders>();
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		 try {
			 ps = connection.prepareStatement("select * from `order` order by order_id");
			 rs = ps.executeQuery();
			 while(rs.next()){
					Orders order = new Orders();
					order.setOrder_id(rs.getInt("order_id"));
					order.setUser_id(rs.getInt("user_id"));
					order.setOrder_time(rs.getString("order_time"));
					list.add(order);
				}
			}catch (SQLException e) {
			e.printStackTrace();
			}finally {
				try {
					rs.close();
					ps.close();
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return list;
	}
	
	public boolean delete(int order_id) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("delete from `order` where order_id=?");
			 ps.setInt(1,order_id);
			 ps.execute();
			 System.out.print(ps.executeUpdate());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	
	public boolean update(int order_id,int user_id,int new_order_id,int new_user_id) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("update `order` set order_id=?,user_id=? where order_id=? and user_id=?");
			 ps.setInt(1,new_order_id);
			 ps.setInt(2,new_user_id);
			 ps.setInt(3,order_id);
			 ps.setInt(4,user_id);
			 ps.execute();
			 System.out.print(ps.executeUpdate());
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	public List<Orders> getListPage(Page page){
		List<Orders> list = new ArrayList<Orders>();
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		try {
			 ps = connection.prepareStatement("select * from `order` order by order_id  limit ?,?");			 
			 ps.setInt(1, (page.getDpage()-1)*page.getPagecount());
			 ps.setInt(2, page.getPagecount());
			 rs = ps.executeQuery();
			while(rs.next()) {
				Orders order = new Orders();
				order.setOrder_id(rs.getInt("order_id"));
				order.setUser_id(rs.getInt("user_id"));
				order.setOrder_time(rs.getString("order_time"));
				list.add(order);
				}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public Integer selectCount(){
		Integer count=0;
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		try {
			 ps = connection.prepareStatement("select count(*) as num from `order`");			 
			
			 rs = ps.executeQuery();
			if(rs.next()) {
				count =rs.getInt("num");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return count;
	}
	
	public int insert(int user_id) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		Calendar now = Calendar.getInstance();
		ResultSet rs=null;
		int count=0;
		try {
			 ps = connection.prepareStatement("INSERT INTO `order`(`user_id`,`order_time`)  VALUE (?,?)");
			 ps.setInt(1, user_id);
			 ps.setString(2, now.get(Calendar.YEAR)+"-"+(now.get(Calendar.MONTH)+1)+"-"+now.get(Calendar.DAY_OF_MONTH));
			 ps.execute();
			 rs = ps.getGeneratedKeys(); //��ȡ���     
			 if (rs.next()) { 
				 count = rs.getInt(1);//ȡ��ID  
			 } else {  
				 
			 }  
			 return count;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return count;
	}
	public List<Orders> getListwithuser(int user_id){
		List<Orders> list = new ArrayList<Orders>();
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		 try {
			 ps = connection.prepareStatement("select * from `order` where user_id=?  order by order_id");
			 ps.setInt(1, user_id);
			 rs = ps.executeQuery();
			 while(rs.next()){
					Orders order = new Orders();
					order.setOrder_id(rs.getInt("order_id"));
					order.setUser_id(rs.getInt("user_id"));
					order.setOrder_time(rs.getString("order_time"));
					list.add(order);
				}
			}catch (SQLException e) {
			e.printStackTrace();
			}finally {
				try {
					rs.close();
					ps.close();
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return list;
	}
	
}
