package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Book;
import bean.BookType;
import db.DBConnection;

public class BookTypeDao {
	public List<BookType> getList(){
		List<BookType> list = new ArrayList<BookType>();
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		 try {
			ps = connection.prepareStatement("select * from booktype order by  type_id");
			rs = ps.executeQuery();
			while(rs.next()){
				BookType book= new BookType();
				book.setType_id(rs.getInt("type_id"));
				book.setType_name(rs.getString("type_name"));
				list.add(book);
			}
			}catch (SQLException e) {
			e.printStackTrace();
			}finally {
				try {
					rs.close();
					ps.close();
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return list;
	}
}
