package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import bean.Admin;
import bean.Book;
import bean.BookType;
import bean.Page;
import bean.Users;
import db.DBConnection;

public class AdminDao {
	public List<Admin> getList(){
		List<Admin> list = new ArrayList<Admin>();
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		 try {
			ps = connection.prepareStatement("select * from admin order by admin_id");
			rs = ps.executeQuery();
			while(rs.next()){
				Admin admin = new Admin();
				admin.setAdmin_id(rs.getInt("admin_id"));
				admin.setAdmin_name(rs.getString("admin_name"));
				admin.setAdmin_password(rs.getString("admin_password"));
				list.add(admin);
			}
			}catch (SQLException e) {
			e.printStackTrace();
			}finally {
				try {
					rs.close();
					ps.close();
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return list;
	}
	
	public Admin login(String admin_name,String admin_password) {
		Admin admin = null;
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		try {
			 ps = connection.prepareStatement("select * from admin where admin_name=? and admin_password=?");
			 ps.setString(1,admin_name);
			 ps.setString(2,admin_password);
			 rs = ps.executeQuery();
			if(rs.next()) {
				admin = new Admin();
				admin.setAdmin_name(admin_name);
				admin.setAdmin_password(admin_password);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return admin;
	}
	public boolean register(int admin_id,String admin_name,String admin_password) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("INSERT INTO `admin`(`admin_id`,`admin_name`, `admin_password`)  VALUE (?,?,?)");
			 ps.setInt(1, admin_id);
			 ps.setString(2, admin_name);
			 ps.setString(3, admin_password);
			 ps.execute();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
//	public List<Admin> getAdmin(){
//		List<Admin> list = new ArrayList<Admin>();
//		Connection connection = DBConnection.getConnection();
//		PreparedStatement ps =null;
//		ResultSet rs=null;
//		 try {
//			ps = connection.prepareStatement("select * from admin");
//			rs = ps.executeQuery();
//			while(rs.next()){
//				Admin admin = new Admin();
//				admin.setAdmin_id(rs.getInt("admin_id"));
//				admin.setAdmin_name(rs.getString("admin_name"));
//				admin.setAdmin_password(rs.getString("admin_password"));
//				list.add(admin);
//			}
//			}catch (SQLException e) {
//			e.printStackTrace();
//			}finally {
//				try {
//					rs.close();
//					ps.close();
//					connection.close();
//				} catch (SQLException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
//		return list;
//	}
	
	public boolean delete(int admin_id,String admin_name,String admin_password) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("delete from `admin` where admin_name=? and admin_password=? and admin_id=?");
			 ps.setString(1,admin_name);
			 ps.setString(2,admin_password);
			 ps.setInt(3,admin_id);
			 ps.execute();
			 System.out.print(ps.executeUpdate());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	public boolean update(String admin_name,String admin_password,String new_admin_name,String new_admin_password) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("update admin set admin_name=?,admin_password=? where admin_name=? and admin_password=?");
			 ps.setString(1,new_admin_name);
			 ps.setString(2,new_admin_password);
			 ps.setString(3,admin_name);
			 ps.setString(4,admin_password);
			 ps.execute();
			 System.out.print(ps.executeUpdate());
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	
	
//	public boolean insert(int admin_id,String admin_name,String admin_password) {
//
//		Connection connection = DBConnection.getConnection();
//		PreparedStatement ps =null;
//		try {
//			 ps = connection.prepareStatement("insert into admin value(?,?,?)");
//			 ps.setInt(1,admin_id);
//			 ps.setString(2,admin_name);
//			 ps.setString(3,admin_password);
//			 System.out.print(ps.executeUpdate());
//			 return true;
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}finally {
//			try {
//				ps.close();
//				connection.close();
//			} catch (SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//		return false;
//	}
//}
	
	public List<Admin> getListPage(Page page){
		List<Admin> list = new ArrayList<Admin>();
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		try {
			 ps = connection.prepareStatement("select * from admin order by admin_id  limit ?,?");			 
			 ps.setInt(1, (page.getDpage()-1)*page.getPagecount());
			 ps.setInt(2, page.getPagecount());
			 rs = ps.executeQuery();
			while(rs.next()) {
				Admin admin = new Admin();
				admin.setAdmin_id(rs.getInt("admin_id"));
				admin.setAdmin_name(rs.getString("admin_name"));
				admin.setAdmin_password(rs.getString("admin_password"));
				list.add(admin);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public Integer selectCount(){
		Integer count=0;
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		try {
			 ps = connection.prepareStatement("select count(*) as num from `admin`");			 
			
			 rs = ps.executeQuery();
			if(rs.next()) {
				count =rs.getInt("num");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return count;
	}
	
}
