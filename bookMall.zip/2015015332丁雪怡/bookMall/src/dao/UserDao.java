 package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Admin;
import bean.Book;
import bean.BookType;
import bean.Page;
import bean.Users;
import db.DBConnection;

public class UserDao {
	public List<Users> getList(){
		List<Users> list = new ArrayList<Users>();
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		 try {
			ps = connection.prepareStatement("select * from users order by user_id");
			rs = ps.executeQuery();
			while(rs.next()){
				Users user = new Users();
				user.setUser_address(rs.getString("user_address"));
				user.setUser_name(rs.getString("user_name"));
				user.setUser_id(rs.getInt("user_id"));
				user.setUser_password(rs.getString("user_password"));
				user.setUser_telephone(rs.getString("user_telephone"));
				list.add(user);
			}
			}catch (SQLException e) {
			e.printStackTrace();
			}finally {
				try {
					rs.close();
					ps.close();
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return list;
	}
	
	public boolean register(String user_name,String user_password,String user_telephone,String user_address) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("INSERT INTO `users`(`user_name`, `user_password`,`user_telephone`,`user_address`)  VALUE (?,?,?,?)");

			 ps.setString(1, user_name);
			 ps.setString(2, user_password);
			 ps.setString(3, user_telephone);
			 ps.setString(4, user_address);
			 ps.execute();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public boolean delete(String user_name,String user_password) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("delete from `users` where user_name=? and user_password=?");
			 ps.setString(1,user_name);
			 ps.setString(2,user_password);
			 ps.execute();
			 System.out.print(ps.executeUpdate());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	
	public boolean update(int user_id,String user_name,String user_password,String user_telephone,String user_address,int new_user_id,String new_user_name,String new_user_password,String new_user_telephone,String new_user_address) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("update `users` set user_id=?,user_name=?,user_password=?,user_telephone=?,user_address=? where user_id=? and user_name=? and user_password=? and user_telephone=? and user_address=?");
			 ps.setInt(1,new_user_id);
			 ps.setString(2,new_user_name);
			 ps.setString(3,new_user_password);
			 ps.setString(4,new_user_telephone);
			 ps.setString(5,new_user_address);
			 ps.setInt(6,user_id);
			 ps.setString(7,user_name);
			 ps.setString(8,user_password);
			 ps.setString(9,user_telephone);
			 ps.setString(10,user_address);
			 ps.execute();
			 System.out.print(ps.executeUpdate());
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public List<Users> getListPage(Page page){
		List<Users> list = new ArrayList<Users>();
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		try {
			 ps = connection.prepareStatement("select * from users order by user_id limit ?,?");			 
			 ps.setInt(1, (page.getDpage()-1)*page.getPagecount());
			 ps.setInt(2, page.getPagecount());
			 rs = ps.executeQuery();
			while(rs.next()) {
				Users user = new Users();
				user.setUser_address(rs.getString("user_address"));
				user.setUser_name(rs.getString("user_name"));
				user.setUser_id(rs.getInt("user_id"));
				user.setUser_password(rs.getString("user_password"));
				user.setUser_telephone(rs.getString("user_telephone"));
				list.add(user);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public Integer selectCount(){
		Integer count=0;
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		try {
			 ps = connection.prepareStatement("select count(*) as num from `users`");			 
			
			 rs = ps.executeQuery();
			if(rs.next()) {
				count =rs.getInt("num");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return count;
	}
	
	public Users login(String user_name,String user_password) {
		Users user = null;
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		try {
			 ps = connection.prepareStatement("select * from users where user_name=? and user_password=?");
			 ps.setString(1,user_name);
			 ps.setString(2,user_password);
			 rs = ps.executeQuery();
			if(rs.next()) {
				user = new Users();
				user.setUser_name(user_name);
				user.setUser_password(user_password);
				user.setUser_address(rs.getString("user_address"));
				user.setUser_telephone(rs.getString("user_telephone"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return user;
	}
	
	public Users selectName(String user_name){
		Integer count=0;
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		Users user=new Users();
		try {
			 ps = connection.prepareStatement("select * from `users` where user_name=?");			 
			 ps.setString(1,user_name);
			 rs = ps.executeQuery();
			if(rs.next()) {
				user.setUser_address(rs.getString("user_address"));
				user.setUser_name(rs.getString("user_name"));
				user.setUser_id(rs.getInt("user_id"));
				user.setUser_password(rs.getString("user_password"));
				user.setUser_telephone(rs.getString("user_telephone"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return user;
	}
	
}
