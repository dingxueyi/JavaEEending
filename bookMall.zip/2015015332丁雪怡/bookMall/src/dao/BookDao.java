package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Page;
import bean.Users;
import bean.Book;
import bean.BookType;
import db.DBConnection;

public class BookDao {
	public List<Book> getList(){
		List<Book> list = new ArrayList<Book>();
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		 try {
			ps = connection.prepareStatement("select * from book,booktype where book.type_id=booktype.type_id order by  book_id");
			rs = ps.executeQuery();
			while(rs.next()){
				Book book = new Book();
				BookType bookType =new BookType();
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_img(rs.getString("book_img"));
				book.setBook_name(rs.getString("book_name"));
				book.setBook_data(rs.getString("book_data"));
				book.setBook_price(rs.getInt("book_price"));
				book.setBook_publisher(rs.getString("book_publisher"));
				bookType.setType_id(rs.getInt("type_id"));
				bookType.setType_name(rs.getString("type_name"));
				book.setBooktype(bookType);
				list.add(book);
			}
			}catch (SQLException e) {
			e.printStackTrace();
			}finally {
				try {
					rs.close();
					ps.close();
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return list;
	}
	
	public boolean delete(String book_name) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("delete from `book` where book_name=?");
			 ps.setString(1,book_name);
			 ps.execute();
			 System.out.print(ps.executeUpdate());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	public boolean update(String book_name,String book_nname,int book_nprice) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("update book set book_name=?,book_price=? where book_name=?" );
			 ps.setString(1,book_nname);
			 ps.setInt(2,book_nprice);
			 ps.setString(3,book_name);
			 ps.execute();
			 System.out.print(ps.executeUpdate());
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	public boolean insert(int book_id,String book_name,String book_publisher,int book_price,String book_img,int type_id,String book_data) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("insert into book value(?,?,?,?,?,?,?)");
			 ps.setInt(1,book_id);
			 ps.setString(2,book_name);
			 ps.setString(3,book_publisher);
			 ps.setInt(4,book_price);
			 ps.setString(5,book_img);
			 ps.setInt(6,type_id);
			 ps.setString(7,book_data);
			 System.out.print(ps.executeUpdate());
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public List<Book> getListPage(Page page){
		List<Book> list = new ArrayList<Book>();
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		try {
			 ps = connection.prepareStatement("select * from book,booktype where book.type_id=booktype.type_id order by  book_id  limit ?,?");			 
			 ps.setInt(1, (page.getDpage()-1)*page.getPagecount());
			 ps.setInt(2, page.getPagecount());
			 rs = ps.executeQuery();
			while(rs.next()) {
				Book book = new Book();
				BookType bookType =new BookType();
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_img(rs.getString("book_img"));
				book.setBook_name(rs.getString("book_name"));
				book.setBook_data(rs.getString("book_data"));
				book.setBook_price(rs.getInt("book_price"));
				book.setBook_publisher(rs.getString("book_publisher"));
				bookType.setType_id(rs.getInt("type_id"));
				bookType.setType_name(rs.getString("type_name"));
				book.setBooktype(bookType);
				list.add(book);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public Integer selectCount(){
		Integer count=0;
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		try {
			 ps = connection.prepareStatement("select count(*) as num from `book`");			 
			
			 rs = ps.executeQuery();
			if(rs.next()) {
				count =rs.getInt("num");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return count;
	}
	
	public Book select(String book_name){
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		Book book=new Book();
		 try {
			ps = connection.prepareStatement("select * from book,booktype where book.type_id=booktype.type_id and book_name=?");
			ps.setString(1,book_name);
			rs = ps.executeQuery();
			if(rs.next()) {
				BookType bookType= new BookType();
				bookType.setType_id(rs.getInt("type_id"));
				bookType.setType_name(rs.getString("type_name"));
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_name(rs.getString("book_name"));
				book.setBook_data(rs.getString("book_data"));
				book.setBook_img(rs.getString("book_img"));
				book.setBook_price(rs.getInt("book_price"));
				book.setBook_publisher(rs.getString("book_publisher"));
				book.setBooktype(bookType);
			}
			}catch (SQLException e) {
			e.printStackTrace();
			}finally {
				try {
					rs.close();
					ps.close();
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return book;
	}
	
	public List<Book> select(int type_id){
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		
		List<Book> list = new ArrayList<Book>();
		 try {
			ps = connection.prepareStatement("select * from book,booktype where book.type_id=booktype.type_id and book.type_id=?");
			ps.setInt(1,type_id);
			rs = ps.executeQuery();
			while(rs.next()) {
				Book book=new Book();
				BookType bookType= new BookType();
				bookType.setType_id(rs.getInt("type_id"));
				bookType.setType_name(rs.getString("type_name"));
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_name(rs.getString("book_name"));
				book.setBook_data(rs.getString("book_data"));
				book.setBook_img(rs.getString("book_img"));
				book.setBook_price(rs.getInt("book_price"));
				book.setBook_publisher(rs.getString("book_publisher"));
				book.setBooktype(bookType);
				list.add(book);
			}
			}catch (SQLException e) {
			e.printStackTrace();
			}finally {
				try {
					rs.close();
					ps.close();
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return list;
	}
	
	public List<Book> find(String word){
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		List<Book> list=new ArrayList<Book>();
		 try {
			ps = connection.prepareStatement("select * from book,booktype where book.type_id=booktype.type_id and(book_name like ? || book_publisher like ? ||type_name like ?)" );
			ps.setString(1,"%"+word+"%");
			ps.setString(2,"%"+word+"%");
			ps.setString(3,"%"+word+"%");
			rs = ps.executeQuery();
			while(rs.next()) {
				Book book=new Book();
				BookType bookType= new BookType();
				bookType.setType_id(rs.getInt("type_id"));
				bookType.setType_name(rs.getString("type_name"));
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_name(rs.getString("book_name"));
				book.setBook_data(rs.getString("book_data"));
				book.setBook_img(rs.getString("book_img"));
				book.setBook_price(rs.getInt("book_price"));
				book.setBook_publisher(rs.getString("book_publisher"));
				book.setBooktype(bookType);
				list.add(book);
			}
			}catch (SQLException e) {
			e.printStackTrace();
			}finally {
				try {
					rs.close();
					ps.close();
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return list;
	}
	public Book selectName(String book_name){
		Integer count=0;
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		Book book=new Book();
		try {
			 ps = connection.prepareStatement("select * from `book` where book_name=?");			 
			 ps.setString(1,book_name);
			 rs = ps.executeQuery();
			if(rs.next()) {
				BookType bookType= new BookType();
				bookType.setType_id(rs.getInt("type_id"));
				bookType.setType_name(rs.getString("type_name"));
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_name(rs.getString("book_name"));
				book.setBook_data(rs.getString("book_data"));
				book.setBook_img(rs.getString("book_img"));
				book.setBook_price(rs.getInt("book_price"));
				book.setBook_publisher(rs.getString("book_publisher"));
				book.setBooktype(bookType);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return book;
	}
}
