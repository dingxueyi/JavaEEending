package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Admin;
import bean.Book;
import bean.OrderDetail;
import db.DBConnection;

public class OrderDetailDao {

	public List<OrderDetail> getList(int order_id){
		List<OrderDetail> list = new ArrayList<OrderDetail>();
		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		ResultSet rs=null;
		 try {
			ps = connection.prepareStatement("select * from `order`,`order_detail`,`book` where order.order_id=order_detail.order_id and order_detail.book_id=book.book_id and order_detail.order_id=? order by order_detail.order_id ");
			ps.setInt(1,order_id);
			rs = ps.executeQuery();
			while(rs.next()){
				OrderDetail orderdetail = new OrderDetail();
				Book book=new Book();
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_name(rs.getString("book_name"));
				orderdetail.setOrder_detail_id(rs.getInt("order_detail_id"));
				orderdetail.setBook(book);
				orderdetail.setOrder_id(rs.getInt("order_id"));
				orderdetail.setCount(rs.getInt("count"));
				list.add(orderdetail);
			}
			}catch (SQLException e) {
			e.printStackTrace();
			}finally {
				try {
					rs.close();
					ps.close();
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		return list;
	}
	
	public boolean insert(int book_id,int count,int order_id) {

		Connection connection = DBConnection.getConnection();
		PreparedStatement ps =null;
		try {
			 ps = connection.prepareStatement("INSERT INTO `order_detail`(`book_id`,`count`, `order_id`)  VALUE (?,?,?)");
			 ps.setInt(1, book_id);
			 ps.setInt(2, count);
			 ps.setInt(3, order_id);
			 ps.execute();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	
	
}
