package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Book;
import bean.Users;
import dao.BookDao;
import dao.CartDao;
import dao.UserDao;

/**
 * Servlet implementation class AddToCartServlet2
 */
@WebServlet("/AddCartServlet2")
public class AddCartServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCartServlet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String book_name=request.getParameter("book_name");
		String page_name=request.getParameter("page_name");
		String user_name=request.getParameter("user_name");
		//��ȡҳ�����ƣ�����ʱʹ��
		Book book=new Book();
		BookDao bookdao=new BookDao();
		book=bookdao.select(book_name);
		CartDao cartdao=new CartDao();
		Users user=new Users();
		UserDao userdao=new UserDao();
		user=userdao.selectName(user_name);
		if(cartdao.insertYesUser(book,user_name)) {
			request.getSession().setAttribute("msg", "���ӹ��ﳵ�ɹ�");
			request.getSession().setAttribute("page_name", page_name);
			request.getSession().setAttribute("user", user);
			response.sendRedirect("user/addcart_jg2.jsp");
			
		}else {
			System.out.print("ʧ���ˣ�!");
			request.getSession().setAttribute("msg", "���ӹ��ﳵʧ��");
			request.getSession().setAttribute("page_name", page_name);
			request.getSession().setAttribute("user", user);
			response.sendRedirect("user/addcart_jg2.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
