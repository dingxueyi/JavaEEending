package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.OrderDao;
import dao.UserDao;

/**
 * Servlet implementation class UpdateUserServlet
 */
@WebServlet("/UpdateUserServlet")
public class UpdateUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int user_id=Integer.parseInt(request.getParameter("user_id"));
		String user_name=request.getParameter("user_name");
		String user_password=request.getParameter("user_password");
		String user_telephone=request.getParameter("user_telephone");
		String user_address=request.getParameter("user_address");
		int new_user_id=Integer.parseInt(request.getParameter("new_user_id"));
		String new_user_name=request.getParameter("new_user_name");
		String new_user_password=request.getParameter("new_user_password");
		String new_user_telephone=request.getParameter("new_user_telephone");
		String new_user_address=request.getParameter("new_user_address");
		UserDao userDao = new UserDao();
		if(userDao.update(user_id,user_name,user_password,user_telephone,user_address,new_user_id,new_user_name,new_user_password,new_user_telephone,new_user_address)) {
			response.sendRedirect("UserListServlet");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
