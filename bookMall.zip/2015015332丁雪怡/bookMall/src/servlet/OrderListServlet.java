package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Admin;
import bean.Book;
import bean.Orders;
import bean.Page;
import dao.AdminDao;
import dao.BookDao;
import dao.OrderDao;

/**
 * Servlet implementation class OrderListServlet
 */
@WebServlet("/OrderListServlet")
public class OrderListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub;
		String pageS = request.getParameter("page");
		Integer dpage=1;
		if(pageS!=null) {
			dpage=Integer.parseInt(pageS);
		}
		Page page = new Page();
		OrderDao orderDao = new OrderDao();
		page.setTotalcount(orderDao.selectCount());
		page.setTotalpage();
		page.setDpage(dpage);
		List<Orders> list  = orderDao.getListPage(page);	
		
		System.out.print(page.getDpage());
		System.out.print(page.getPagecount());
		System.out.print(page.getTotalpage());
		request.getSession().setAttribute("page", page);
		request.getSession().setAttribute("orderslist", list);
		response.sendRedirect("admin/order_list.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
