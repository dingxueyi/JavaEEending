package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.*;
import dao.*;

/**
 * Servlet implementation class UserCenterServlet
 */
@WebServlet("/UserCenterServlet")
public class UserCenterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserCenterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String user_name=request.getParameter("user_name");
		Users user=new Users();
		UserDao userdao=new UserDao();
		Book book =new Book();
		BookDao bookdao= new BookDao();
		Orders order=new Orders();
		OrderDao orderdao=new OrderDao();
		OrderDetail od=new OrderDetail();
		OrderDetailDao odd=new OrderDetailDao();
		user=userdao.selectName(user_name);
		List <Orders> orderlist=orderdao.getListwithuser(user.getUser_id());
		List <OrderDetail> odl=new ArrayList<OrderDetail>();
		List <List> ll=new ArrayList<List>();
		for(int i=0;i<orderlist.size();i++) {
			odl=odd.getList(orderlist.get(i).getOrder_id());
			ll.add(odl);
		}
		request.getSession().setAttribute("ll", ll);
		request.getSession().setAttribute("user", user);
		response.sendRedirect("user/user_center.jsp");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
