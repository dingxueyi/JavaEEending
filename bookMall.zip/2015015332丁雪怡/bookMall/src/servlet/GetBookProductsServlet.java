package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Book;
import dao.BookDao;

/**
 * Servlet implementation class GetBookProductsServlet
 */
@WebServlet("/GetBookProductsServlet")
public class GetBookProductsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetBookProductsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		if(request.getParameter("type_id")==null) {
			List<Book> list  = new ArrayList<Book>();	
			BookDao bookDao=new BookDao();
			if(bookDao.getList() != null) {
				String yes="";
				list=bookDao.getList();
				request.getSession().setAttribute("list", list);
				request.getSession().setAttribute("yes", "yes");
				response.sendRedirect("user/products.jsp");
			}
		}else {
			int type_id=Integer.parseInt(request.getParameter("type_id"));
			List<Book> list  = new ArrayList<Book>();	
			BookDao bookDao=new BookDao();
			if(bookDao.select(type_id) != null) {
				list=bookDao.select(type_id);
				request.getSession().setAttribute("list", list);
				request.getSession().setAttribute("yes", "no");
				response.sendRedirect("user/products.jsp");
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
