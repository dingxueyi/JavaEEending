package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Book;
import bean.Users;
import dao.BookDao;
import dao.UserDao;

/**
 * Servlet implementation class FindServlet2
 */
@WebServlet("/FindServlet2")
public class FindServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FindServlet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String word=request.getParameter("word");
		String user_name=request.getParameter("user_name");
		BookDao bookDao=new BookDao();
		Users user=new Users();
		UserDao userdao=new UserDao();
		user=userdao.selectName(user_name);
		List<Book> list=new ArrayList<Book>();
		if(bookDao.find(word)!=null) {
			list=bookDao.find(word);
			request.getSession().setAttribute("list",list);
			request.getSession().setAttribute("user", user);
			response.sendRedirect("user/products2.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
