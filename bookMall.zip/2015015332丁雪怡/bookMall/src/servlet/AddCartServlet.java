package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Book;
import dao.BookDao;
import dao.CartDao;

/**
 * Servlet implementation class AddCartServlet
 */
@WebServlet("/AddCartServlet")
public class AddCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String book_name=request.getParameter("book_name");
		String page_name=request.getParameter("page_name");
		System.out.print("ִ�е������ˣ�");
		//��ȡҳ�����ƣ�����ʱʹ��
		Book book=new Book();
		BookDao bookdao=new BookDao();
		book=bookdao.select(book_name);
		CartDao cartdao=new CartDao();
		if(cartdao.insertNoUser(book)) {
			System.out.print("�ӽ�ȥ��!");
			request.getSession().setAttribute("msg", "���ӹ��ﳵ�ɹ�");
			request.getSession().setAttribute("page_name", page_name);
			response.sendRedirect("user/addcart_jg.jsp");
			
		}else {
			System.out.print("ʧ���ˣ�!");
			request.getSession().setAttribute("msg", "���ӹ��ﳵʧ��");
			request.getSession().setAttribute("page_name", page_name);
			response.sendRedirect("user/addcart_jg.jsp");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
