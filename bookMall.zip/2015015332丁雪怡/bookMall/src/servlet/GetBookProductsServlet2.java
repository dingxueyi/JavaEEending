package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Book;
import bean.Users;
import dao.BookDao;
import dao.UserDao;

/**
 * Servlet implementation class GetBookProductsServlet2
 */
@WebServlet("/GetBookProductsServlet2")
public class GetBookProductsServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetBookProductsServlet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String user_name=request.getParameter("user_name");
		Users user=new Users();
		UserDao userdao=new UserDao();
		user=userdao.selectName(user_name);
		if(request.getParameter("type_id")==null) {
			List<Book> list  = new ArrayList<Book>();	
			BookDao bookDao=new BookDao();
			if(bookDao.getList() != null) {
				String yes="";
				list=bookDao.getList();
				request.getSession().setAttribute("list", list);
				request.getSession().setAttribute("yes", "yes");
				request.getSession().setAttribute("user", user);
				response.sendRedirect("user/products2.jsp");
			}
		}else {
			int type_id=Integer.parseInt(request.getParameter("type_id"));
			List<Book> list  = new ArrayList<Book>();	
			BookDao bookDao=new BookDao();
			if(bookDao.select(type_id) != null) {
				list=bookDao.select(type_id);
				request.getSession().setAttribute("list", list);
				request.getSession().setAttribute("user", user);
				request.getSession().setAttribute("yes", "no");
				response.sendRedirect("user/products2.jsp");
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
