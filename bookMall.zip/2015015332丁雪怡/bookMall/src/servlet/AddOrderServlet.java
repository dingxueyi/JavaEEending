package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Book;
import bean.Cart;
import bean.Users;
import dao.BookDao;
import dao.CartDao;
import dao.OrderDao;
import dao.OrderDetailDao;
import dao.UserDao;

/**
 * Servlet implementation class AddOrderServlet
 */
@WebServlet("/AddOrderServlet")
public class AddOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String user_name=request.getParameter("user_name");
		Users user=new Users();
		UserDao userdao=new UserDao();
		user=userdao.selectName(user_name);
		user=userdao.selectName(user_name);
		CartDao cartdao=new CartDao();
		List <Cart>list=new ArrayList<Cart>();
		list=cartdao.CartListUser(user_name);
		cartdao.deletewithuser(user_name);
		OrderDao orderdao=new OrderDao();
		OrderDetailDao oddao=new OrderDetailDao();
		int order_id=orderdao.insert(user.getUser_id());
		System.out.println(order_id);
		for(int j=0;j<list.size();j++) {
			Book book =new Book();
			BookDao bookdao=new BookDao();
			book=bookdao.select(list.get(j).getBook_name());
			System.out.println(book.getBook_id());
			System.out.println(list.get(j).getCount());
			oddao.insert(book.getBook_id(), list.get(j).getCount(),order_id);
		}
		request.getSession().setAttribute("user", user);
		response.sendRedirect("user/hadaffirm.jsp");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
