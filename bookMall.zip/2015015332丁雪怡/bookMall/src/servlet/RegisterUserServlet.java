package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Users;
import dao.UserDao;

/**
 * Servlet implementation class RegisterUserServlet
 */
@WebServlet("/RegisterUserServlet")
public class RegisterUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		int user_id=Integer.parseInt(request.getParameter("user_id"));
		String user_name=request.getParameter("user_name");
		String user_password=request.getParameter("user_password");
		String user_re_password=request.getParameter("user_re_password");
		String user_telephone=request.getParameter("user_telephone");
		String user_address=request.getParameter("user_address");
		UserDao userdao = new UserDao();
		Users user=new Users();
		if(userdao.register(user_name, user_password, user_telephone, user_address)) {
			request.getSession().setAttribute("yes", "����ע��ɹ���");
			response.sendRedirect("user/register2.jsp");
		}else {
			request.getSession().setAttribute("yes", "��˶���Ϣ����ע�ᣡ");
			response.sendRedirect("user/register2.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
