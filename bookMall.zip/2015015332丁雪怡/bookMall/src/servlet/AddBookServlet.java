package servlet;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import bean.BookType;
import dao.AdminDao;
import dao.BookDao;

/**
 * Servlet implementation class AddBookServlet
 */
@WebServlet("/AddBookServlet")
public class AddBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddBookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		int book_id=Integer.parseInt(request.getParameter("book_id"));
		String book_name=request.getParameter("book_name");
		String book_publisher=request.getParameter("book_publisher");
		String book_data=request.getParameter("book_data");
		int book_price=Integer.parseInt(request.getParameter("book_price"));
		String book_img=request.getParameter("book_img");	
		int type_id=Integer.parseInt(request.getParameter("type_id"));
		BookDao bookdao = new BookDao();
		book_img="../image/"+book_img;
		
		DiskFileItemFactory dff= new DiskFileItemFactory();
		ServletFileUpload sfu = new ServletFileUpload(dff);
		String realPath = getServletContext().getRealPath("image");
		try {
			List<FileItem> fileitems = sfu.parseRequest(request);
			for(FileItem fi:fileitems) {
				if(fi.isFormField()) {
					String name = fi.getString("UTF-8");
					request.setAttribute("name", name);
				}else {
					String name = fi.getName();
					int start = name.lastIndexOf("\\");
					name.substring(start+1);
					System.out.println(name);
					fi.write(new File(realPath+"\\"+name.substring(start+1)));
					request.setAttribute("image",name.substring(start+1));	
					}
				}
		}catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	    if(bookdao.insert(book_id,book_name,book_publisher,book_price,book_img,type_id,book_data)) {
			request.getSession().setAttribute("msg", "���ӳɹ�");
			response.sendRedirect("admin/add_book.jsp");
		}
		else {
			request.getSession().setAttribute("msg", "����ʧ��");
			response.sendRedirect("admin/add_book.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
