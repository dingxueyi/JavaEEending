﻿# SQL Manager 2007 Lite for MySQL 4.4.2.1
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : bookMall_db


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

SET FOREIGN_KEY_CHECKS=0;

CREATE DATABASE `bookMall_db`
    CHARACTER SET 'utf8'
    COLLATE 'utf8_general_ci';

USE `bookmall_db`;

#
# Structure for the `admin` table : 
#

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(20) DEFAULT NULL,
  `admin_password` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=1638;

#
# Structure for the `booktype` table : 
#

CREATE TABLE `booktype` (
  `type_id` int(11) NOT NULL,
  `type_name` varchar(20) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for the `book` table : 
#

CREATE TABLE `book` (
  `book_id` int(11) NOT NULL DEFAULT '0',
  `book_name` varchar(20) DEFAULT NULL,
  `book_publisher` varchar(20) DEFAULT NULL,
  `book_price` int(11) DEFAULT NULL,
  `book_img` varchar(100) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `book_data` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`book_id`),
  KEY `type_id` (`type_id`),
  CONSTRAINT `book_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `booktype` (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=8192;

#
# Structure for the `cart` table : 
#

CREATE TABLE `cart` (
  `book_img` varchar(100) DEFAULT NULL,
  `book_name` varchar(20) DEFAULT NULL,
  `book_price` int(11) DEFAULT NULL,
  `user_name` varchar(20) DEFAULT NULL,
  `cart_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`cart_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

#
# Structure for the `order` table : 
#

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `order_time` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

#
# Structure for the `order_detail` table : 
#

CREATE TABLE `order_detail` (
  `order_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_detail_id`),
  KEY `order_id` (`order_id`),
  KEY `c2` (`book_id`),
  CONSTRAINT `c2` FOREIGN KEY (`book_id`) REFERENCES `book` (`book_id`),
  CONSTRAINT `c1` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

#
# Structure for the `users` table : 
#

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_password` varchar(20) DEFAULT NULL,
  `user_telephone` varchar(20) DEFAULT NULL,
  `user_address` varchar(40) DEFAULT NULL,
  `user_name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

#
# Data for the `admin` table  (LIMIT 0,500)
#

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_password`) VALUES 
  (1,'ding','123'),
  (2,'zhao','123'),
  (3,'han','234'),
  (4,'gao','123'),
  (5,'mi','123'),
  (6,'li','123');
COMMIT;

#
# Data for the `booktype` table  (LIMIT 0,500)
#

INSERT INTO `booktype` (`type_id`, `type_name`) VALUES 
  (1,'文学'),
  (2,'科幻'),
  (3,'校园'),
  (4,'教育'),
  (5,'童书'),
  (6,'传记'),
  (7,'名著'),
  (8,'生活');
COMMIT;

#
# Data for the `book` table  (LIMIT 0,500)
#

INSERT INTO `book` (`book_id`, `book_name`, `book_publisher`, `book_price`, `book_img`, `type_id`, `book_data`) VALUES 
  (1,'丁丁历险记','埃尔热 ',198,'../image/丁丁历险记.jpg',5,'走进丁丁的世界，一起上天下海，翻雪山，过沙漠，周游世界；走出丁丁的世界，一起探奇历险，惩恶扬善，信诺言，懂宽容。'),
  (2,'平凡的世界','路遥',70,'../image/平凡的世界.jpg',1,'茅盾文学奖皇冠上的明珠，激励亿万读者的不朽经典。深受老师和学生喜爱的新课标必读书'),
  (3,'三体','刘慈欣',30,'../image/三体.jpg',2,'慈欣基于科学事实，用大胆的想象和严谨的推断，在三体星系行星中构建了一个外星文明形态，并描绘了该文明不可捉摸的数百次的毁灭和重生。'),
  (4,'红玫瑰与白玫瑰','张爱玲',17,'../image/红玫瑰与白玫瑰.jpg',1,'话剧百年收官之作，金马奖五项大奖电影《红玫瑰与白玫瑰》原著小说。'),
  (5,'Java从入门到精通','明日科技',49,'../image/Java从入门到精通.jpg',4,'畅销书全新改版 累计63次重印 30万读者选择的 java入门经典书 持续八年畅销 全行业优秀畅销书 长期位居java 销售排行榜前列 '),
  (6,'疯狂Java讲义','李刚 ',99,'../image/疯狂Java讲义.jpg',4,'国内知名IT图书作家李刚老师针对Java 8推出的全新升级版；国内知名IT图书作家李刚老师针对Java 8推出的全新升级版；'),
  (7,'史蒂夫·乔布斯传','沃尔特.艾萨克森',43,'../image/史蒂夫·乔布斯传.jpg',6,'在原有《乔布斯传》的基础上，修订了全部译文，采纳了读者对翻译的众多建议，使得整体译文更加完善，更加精良。'),
  (8,'张学良全传','张学继',53,'../image/张学良全传.jpg',6,'一部关于张学良将军生平的传记著作。 家喻户晓的张学良将军， 是一位充满传奇性和浪漫性的历史人物。'),
  (9,'西游记','吴承恩',25,'../image/西游记.jpg',7,'推荐购买权威定本 人民文学版四大名著。该版的《西游记》，不仅价格便宜、印刷美观、装帧古朴，收藏、送人都让你特有面子！'),
  (10,'红楼梦','曹雪芹',33,'../image/红楼梦.jpg',7,'本书为中国古典文学读本丛书。 该版的《红楼梦》，不仅价格便宜、印刷美观、装帧古朴，收藏、送人都让你特有面子！'),
  (11,'三国演义','罗贯中',24,'../image/三国演义.jpg',7,'推荐购买权威定本 人民文学版四大名著 '),
  (12,'水浒传','施耐庵',28,'../image/水浒传.jpg',7,'推荐购买权威定本 人民文学版四大名著'),
  (13,'我与世界只差一个你','张皓宸',28,'../image/我与世界只差一个你.jpg',3,'90后实力写作者，张皓宸全新力作，带来温暖人心的个人故事集。12个温馨治愈的情感故事，给年轻人爱的正能量和信心。'),
  (14,'时间的女儿','八月长安',33,'../image/时间的女儿.jpg',3,'暌违三年，全新图书。 八月长安首部描写成长、青春、旅程的散文集。 全彩精装'),
  (15,'阿凡提的大智慧','艾克拜尔·吾拉木',40,'../image/阿凡提的大智慧.jpg',5,'阿凡提故事历来广受读者欢迎，智慧故事蕴意隽永，有助于启发读者思维；幽默故事能培养读者的幽默感，帮助他们形成乐观豁达的人生态度。'),
  (16,'减肥不是挨饿，而是与食物合作','[美]伊芙琳特里弗雷',30,'../image/减肥不是挨饿，而是与食物合作.jpg',8,'这本颠覆性的书，畅销美国22年，让1000万人彻底告别肥胖。'),
  (17,'我与地坛','史铁生',12,'../image/我与地坛.jpg',1,'一篇长篇哲思抒情散文,史铁生所著，充满哲思又极为人性化的代表作之一。');
COMMIT;

#
# Data for the `order` table  (LIMIT 0,500)
#

INSERT INTO `order` (`order_id`, `user_id`, `order_time`) VALUES 
  (10,1,'2017-10-18'),
  (11,1,'2017-10-18'),
  (12,1,'2017-10-18'),
  (13,1,'2017-10-18'),
  (14,1,'2017-10-20');
COMMIT;

#
# Data for the `order_detail` table  (LIMIT 0,500)
#

INSERT INTO `order_detail` (`order_detail_id`, `book_id`, `count`, `order_id`) VALUES 
  (5,1,2,10),
  (6,2,3,11),
  (7,3,2,12),
  (8,12,10,13),
  (9,4,12,10),
  (10,1,1,14),
  (11,2,2,14);
COMMIT;

#
# Data for the `users` table  (LIMIT 0,500)
#

INSERT INTO `users` (`user_id`, `user_password`, `user_telephone`, `user_address`, `user_name`) VALUES 
  (1,'123','12345678900','Shijiazhuang','dingding'),
  (2,'123','12345678900','Handan','zhaozhao'),
  (3,'123','12345678900','Zhuozhou','hanhan'),
  (4,'123','12345678900','Chengde','gao'),
  (5,'123','12345678900','sjz','ma'),
  (6,'123','12345678900','china','lv'),
  (7,'123','12345678900','sjz','alading'),
  (13,'123','12345678900','hd','zhao');
COMMIT;



/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;